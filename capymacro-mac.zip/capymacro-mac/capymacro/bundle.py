"""Build a real CapyMacro.app so macOS will list it by name.

The `+` button in Privacy & Security only accepts `.app` bundles — that is why
the loose files in the macro folder are greyed out there. This makes a small
double-clickable bundle next to run.sh; granting permissions to CapyMacro.app and
launching that is the reliable way to get Accessibility and Screen Recording.
"""

from __future__ import annotations

from pathlib import Path

from . import ROOT

APP_NAME = "CapyMacro.app"

INFO_PLIST = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleName</key>
    <string>CapyMacro</string>
    <key>CFBundleDisplayName</key>
    <string>CapyMacro</string>
    <key>CFBundleIdentifier</key>
    <string>com.capymacro.launcher</string>
    <key>CFBundleVersion</key>
    <string>0.1.0</string>
    <key>CFBundleShortVersionString</key>
    <string>0.1.0</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleExecutable</key>
    <string>CapyMacro</string>
    <key>LSMinimumSystemVersion</key>
    <string>11.0</string>
    <key>NSHighResolutionCapable</key>
    <true/>
</dict>
</plist>
"""

LAUNCHER = """#!/bin/bash
# Created by CapyMacro. The project path is baked in, so the bundle opens even
# if it is moved to the Desktop or Applications.
PROJECT="__PROJECT__"
LOG="$PROJECT/data/launch.log"

if [ ! -f "$PROJECT/run.sh" ]; then
  /usr/bin/osascript -e 'display alert "CapyMacro" message "The project folder moved. Open the macro folder and press Permissions → Create CapyMacro.app again."'
  exit 1
fi

cd "$PROJECT" || exit 1
mkdir -p "$PROJECT/data"
printf '\\n=== %s ===\\n' "$(date)" >> "$LOG"
# Called through bash so a missing +x bit (common after unzipping) cannot stop it.
/bin/bash "$PROJECT/run.sh" >> "$LOG" 2>&1
status=$?
if [ "$status" -ne 0 ]; then
  /usr/bin/osascript -e "display alert \\\"CapyMacro stopped\\\" message \\\"Exit code $status. Details: $LOG\\\""
fi
"""


def app_path(root: Path | None = None) -> Path:
    return (root or ROOT) / APP_NAME


def create_app_bundle(root: Path | None = None) -> Path:
    """Write (or refresh) CapyMacro.app and return its path."""
    app = app_path(root)
    macos = app / "Contents" / "MacOS"
    macos.mkdir(parents=True, exist_ok=True)

    (app / "Contents" / "Info.plist").write_text(INFO_PLIST, encoding="utf-8")
    (app / "Contents" / "PkgInfo").write_text("APPL????", encoding="utf-8")

    project = str((root or ROOT).resolve())
    (macos / "CapyMacro").parent.mkdir(parents=True, exist_ok=True)
    launcher = macos / "CapyMacro"
    launcher.write_text(LAUNCHER.replace("__PROJECT__", project), encoding="utf-8")
    launcher.chmod(0o755)
    return app
