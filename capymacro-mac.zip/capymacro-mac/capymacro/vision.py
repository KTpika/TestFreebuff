"""Apple Vision text recognition, used to read the wave counter.

No OCR models ship with CapyMacro: macOS has Vision built in, so this works
offline and needs no extra downloads. Import failures are swallowed so the app
can still run (without wave detection) on a machine where Vision is missing.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

import cv2
import numpy as np

try:  # macOS only
    import Quartz
    import Vision

    HAVE_VISION = True
except Exception:  # pragma: no cover - non-macOS development machines
    Quartz = None
    Vision = None
    HAVE_VISION = False

@dataclass(frozen=True)
class Line:
    """One recognised line of text with its centre in image pixels."""

    text: str
    x: float
    y: float
    width: float
    height: float


_WORD = re.compile(r"[a-z0-9]+")
_WAVE = re.compile(r"wave\s*(\d+)", re.IGNORECASE)
_HEARTS = re.compile(r"hearts?\D{0,12}?(\d{1,2})", re.IGNORECASE)
_HEARTS_BEFORE = re.compile(r"(\d{1,2})\s*(?:/|of)?\s*\d{0,2}\s*hearts?", re.IGNORECASE)


def available() -> bool:
    return HAVE_VISION


def _cgimage(image: np.ndarray):
    height, width = image.shape[:2]
    rgb = np.ascontiguousarray(image[:, :, ::-1])  # BGR -> RGB
    data = rgb.tobytes()
    provider = Quartz.CGDataProviderCreateWithData(None, data, len(data), None)
    colour_space = Quartz.CGColorSpaceCreateDeviceRGB()
    return Quartz.CGImageCreate(
        width,
        height,
        8,
        24,
        width * 3,
        colour_space,
        Quartz.kCGImageAlphaNone,
        provider,
        None,
        False,
        Quartz.kCGRenderingIntentDefault,
    )


def read_lines(image: np.ndarray, fast: bool = False, max_width: int = 1600) -> list[Line]:
    """Every line of text Vision can find, with where it was on screen.

    ``fast`` uses the quick recognition level (used by the captcha guard and the
    Play/Reconnect detector, which run every few seconds); ``max_width``
    downsizes the input first so a full window screenshot does not cost a
    full-resolution OCR pass. Positions are reported in original image pixels.
    """
    if not HAVE_VISION or image is None or image.size == 0:
        return []

    original_width = image.shape[1]
    factor = 1.0
    if max_width and original_width > max_width:
        factor = original_width / float(max_width)
        image = cv2.resize(
            image,
            None,
            fx=1.0 / factor,
            fy=1.0 / factor,
            interpolation=cv2.INTER_AREA,
        )

    cg_image = _cgimage(image)
    if cg_image is None:
        return []

    handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(cg_image, None)
    request = Vision.VNRecognizeTextRequest.alloc().init()
    level = (
        Vision.VNRequestTextRecognitionLevelFast
        if fast
        else Vision.VNRequestTextRecognitionLevelAccurate
    )
    request.setRecognitionLevel_(level)
    request.setUsesLanguageCorrection_(False)

    try:
        handler.performRequests_error_([request], None)
    except Exception:
        return []

    height, width = image.shape[:2]
    lines: list[Line] = []
    for observation in request.results() or []:
        candidates = observation.topCandidates_(1)
        if not candidates:
            continue
        box = observation.boundingBox()
        # Vision reports normalised boxes with the origin at the bottom left.
        centre_x = (float(box.origin.x) + float(box.size.width) / 2.0) * width * factor
        centre_y = (1.0 - float(box.origin.y) - float(box.size.height) / 2.0) * height * factor
        lines.append(
            Line(
                text=str(candidates[0].string()),
                x=centre_x,
                y=centre_y,
                width=float(box.size.width) * width * factor,
                height=float(box.size.height) * height * factor,
            )
        )
    return lines


def read_text(image: np.ndarray, fast: bool = False, max_width: int = 1600) -> list[str]:
    """Every line of text Vision can find in a BGR image."""
    return [line.text for line in read_lines(image, fast=fast, max_width=max_width)]


def find_word(
    image: np.ndarray,
    words,
    fast: bool = True,
    max_width: int = 1280,
    max_words: int | None = None,
) -> Line | None:
    """The widest line whose words include one of ``words``.

    Whole words only, so "Players" is not a match for "play"; ``max_words``
    skips sentences, which keeps a button label from matching chat text.
    """
    wanted = {str(word).lower() for word in words}
    if not wanted:
        return None

    best: Line | None = None
    for line in read_lines(image, fast=fast, max_width=max_width):
        tokens = set(_WORD.findall(line.text.lower()))
        if not (tokens & wanted):
            continue
        if max_words is not None and len(tokens) > max_words:
            continue
        if best is None or line.width > best.width:
            best = line
    return best


def hearts_number(image: np.ndarray, top: float = 0.35) -> int | None:
    """Read the dungeon heart count from the top of the HUD, e.g. "Hearts 2"."""
    if not HAVE_VISION or image is None or image.size == 0:
        return None

    band = image[: max(1, int(image.shape[0] * max(0.05, min(top, 1.0)))), :]
    best: int | None = None
    for line in read_text(band, fast=True, max_width=1280):
        for pattern in (_HEARTS, _HEARTS_BEFORE):
            for found in pattern.findall(line):
                value = int(found)
                if best is None or value < best:
                    best = value
    return best


def wave_number(image: np.ndarray) -> int | None:
    """Read the current wave from the HUD, e.g. "Wave 6"."""
    best: int | None = None
    for line in read_text(image):
        for found in _WAVE.findall(line):
            value = int(found)
            if best is None or value > best:
                best = value
    return best
