"""Template library and the screen-facing half of the bot."""

from __future__ import annotations

import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np

from .. import TEMPLATES, keys, screen, window
from ..coords import Rect


@dataclass(frozen=True)
class Hit:
    x: int
    y: int
    score: float
    name: str


class AssetIndex:
    """Finds `templates/AA/**/<name>.png` by short name."""

    def __init__(self, root: Path = TEMPLATES / "AA"):
        self.root = root
        self._index: dict[str, Path] | None = None

    def refresh(self) -> None:
        index: dict[str, Path] = {}
        if self.root.exists():
            for path in self.root.rglob("*.png"):
                index.setdefault(path.stem.lower(), path)
        self._index = index

    def path(self, name: str) -> Path | None:
        if self._index is None:
            self.refresh()
        assert self._index is not None
        key = name.lower()
        if key.endswith(".png"):
            key = key[:-4]
        return self._index.get(key)

    def names(self) -> list[str]:
        if self._index is None:
            self.refresh()
        return sorted(self._index or {})


class GameView:
    """Screenshot/locate/click against the live Roblox window."""

    def __init__(self, assets: AssetIndex | None = None):
        self.assets = assets or AssetIndex()
        self.last_rect: Rect | None = None
        self.last_pid: int | None = None
        self._scale_hints: dict[str, float] = {}

    # ---------------------------------------------------------------- window

    def target(self) -> tuple[Rect, int] | None:
        found = window.find_game_window()
        if found is None:
            return None
        self.last_rect = found.rect
        self.last_pid = found.pid
        return found.rect, found.pid

    def focus(self) -> None:
        if self.last_pid:
            window.activate(self.last_pid)

    def rect(self) -> Rect | None:
        return self.last_rect if self.last_rect is not None else (self.target() or (None, 0))[0]

    def frame(self, rect: Rect | None = None) -> np.ndarray | None:
        rect = rect or self.rect()
        if rect is None:
            return None
        centre_x, centre_y = rect.center
        return screen.capture(rect, window.scale_at(centre_x, centre_y))

    # ----------------------------------------------------------------- match

    def locate(self, name: str, frame: np.ndarray | None = None, threshold: float = 0.85) -> Hit | None:
        rect = self.rect()
        if rect is None:
            return None
        template = self.assets.path(name)
        if template is None:
            return None
        image = screen.load_template(template)
        if image is None:
            return None
        if frame is None:
            frame = self.frame(rect)
        if frame is None:
            return None
        match = screen.find_template(
            frame, image, threshold=threshold, hint=self._scale_hints.get(name)
        )
        if match is None or match.score < threshold:
            return None
        self._scale_hints[name] = match.scale
        return Hit(
            x=rect.left + match.x,
            y=rect.top + match.y,
            score=match.score,
            name=name,
        )

    def hit_at(self, x: float, y: float, name: str, score: float = 1.0) -> Hit | None:
        """Turn a point inside the captured frame into a clickable Hit."""
        rect = self.rect()
        if rect is None:
            return None
        return Hit(
            x=int(rect.left + x),
            y=int(rect.top + y),
            score=score,
            name=name,
        )

    def wait_for(
        self,
        names: Iterable[str],
        timeout: float,
        stop=None,
        threshold: float = 0.85,
        interval: float = 0.4,
        on_tick=None,
    ) -> Hit | None:
        """First of ``names`` to appear on screen, or None after ``timeout``.

        ``on_tick`` runs once per poll (the engine passes its captcha guard), so
        waiting for a slow outcome never means waiting blind.
        """
        deadline = time.monotonic() + max(0.1, timeout)
        names = list(names)
        while True:
            if on_tick is not None:
                on_tick()
            rect = self.rect()
            if rect is None:
                return None
            frame = self.frame(rect)
            for name in names:
                hit = self.locate(name, frame=frame, threshold=threshold)
                if hit is not None:
                    return hit
            if time.monotonic() >= deadline:
                return None
            if stop is not None:
                if stop.wait(interval):
                    return None
            else:
                time.sleep(interval)


def click_at(x: int, y: int, pid: int | None) -> None:
    """Bring the game forward and click a screen point."""
    if pid:
        window.activate(pid)
    keys.click(x, y)
