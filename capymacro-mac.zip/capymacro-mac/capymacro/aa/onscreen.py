"""Reading the buttons and notices the shipped templates do not cover.

Disconnect dialogs and the Roblox "Play" button are text, not fixed images, so
they are found with Apple Vision OCR and clicked at the position Vision reports.
"""

from __future__ import annotations

import re

from .. import vision
from .assets import Hit

# Labels are compared after removing punctuation and spacing, and whole words
# only, so a stray "Players" is not mistaken for the Play button.
PLAY_WORDS = ("play", "playagain")
# The queue panel has its own "Play Here": it starts a private run, not the
# queue, so it must never be taken for the lobby Play button.
PLAY_REJECT = ("here", "match", "join", "party", "players")
FIND_MATCH_WORDS = ("findmatch", "matchmake", "matchmaking", "quickmatch")
# The panel's title is "Join Matchmaking?" — a heading, not the button.
FIND_MATCH_REJECT = ("join", "joining")
QUEUE_DIALOG = "joinmatchmaking"

RECONNECT_WORDS = ("reconnect", "rejoin")
LEAVE_WORDS = ("leave", "close", "ok", "continue", "dismiss")
LOBBY_WORDS = ("lobby", "backtolobby", "returntolobby", "returnlobby")

# Matched against compacted OCR text, so punctuation and spacing do not matter.
DISCONNECT_KEYWORDS = (
    "disconnected",
    "connectionlost",
    "lostconnection",
    "errorcode278",
    "errorcode277",
    "errorcode268",
    "youwerdisconnected",
    "reconnecting",
    "failedtoconnect",
)

_NOT_WORD = re.compile(r"[^a-z0-9]+")
_WORD = re.compile(r"[a-z0-9]+")


def _compact(text: str) -> str:
    return _NOT_WORD.sub("", (text or "").lower())


def disconnect_reason(text: str) -> str | None:
    """The disconnect phrase found in a page of text, if any (pure)."""
    compact = _compact(text)
    if not compact:
        return None
    for keyword in DISCONNECT_KEYWORDS:
        if keyword in compact:
            return keyword
    return None


def disconnected(frame) -> str | None:
    """Look for a disconnect notice on screen."""
    if frame is None or not vision.available():
        return None
    return disconnect_reason(" ".join(vision.read_text(frame, fast=True, max_width=1280)))


def _label(view, frame, words, reject=()) -> Hit | None:
    """Click the label that reads like one of ``words`` and none of ``reject``.

    "Find Match" is one button, so its words are compared together: the widest
    line whose compacted text (or one of whose words) matches is the button.
    A line holding a reject word is skipped — otherwise the widest match near
    the queue panel is its "Join Matchmaking?" heading.
    """
    if not vision.available():
        return None
    if frame is None:
        frame = view.frame()
    if frame is None:
        return None

    wanted = {_compact(word) for word in words}
    rejected = {str(word).lower() for word in reject}
    best = None
    for line in vision.read_lines(frame, fast=True, max_width=1280):
        text = (line.text or "").strip()
        tokens = set(_WORD.findall(text.lower()))
        # Buttons are short labels: a sentence that happens to contain "play"
        # (chat, a description) is not the Play button.
        if not tokens or tokens & rejected or len(tokens) > 3:
            continue
        if _compact(text) not in wanted and not tokens & wanted:
            continue
        if best is None or line.width > best.width:
            best = line

    if best is None:
        return None
    return view.hit_at(best.x, best.y, (best.text or "").strip().lower() or "text")


def play_button(view, frame=None) -> Hit | None:
    """The Roblox Play / Play Again button, when it is on screen."""
    return _label(view, frame, PLAY_WORDS, PLAY_REJECT)


def find_match_button(view, frame=None) -> Hit | None:
    """The Find Match button in the Summer "Join Matchmaking?" panel."""
    return _label(view, frame, FIND_MATCH_WORDS, FIND_MATCH_REJECT)


def matchmaking_button(view, frame=None) -> Hit | None:
    """A Matchmaking / Find Match button; the queue panel's is Find Match."""
    return find_match_button(view, frame)


def queue_dialog_open(frame) -> bool:
    """True when the Summer "Join Matchmaking?" panel is on screen."""
    if frame is None or not vision.available():
        return False
    text = " ".join(vision.read_text(frame, fast=True, max_width=1280))
    return QUEUE_DIALOG in _compact(text)


def reconnect_button(view, frame=None) -> Hit | None:
    """The Reconnect / Rejoin button on a Roblox disconnect dialog."""
    return _label(view, frame, RECONNECT_WORDS)


def lobby_button(view, frame=None) -> Hit | None:
    """The button that takes you back to the lobby after a match."""
    return _label(view, frame, LOBBY_WORDS)


def leave_button(view, frame=None) -> Hit | None:
    """A neutral dismiss button for dialogs that have no Reconnect."""
    return _label(view, frame, LEAVE_WORDS)
