"""Finding, focusing and measuring the Roblox window on macOS."""

from __future__ import annotations

import os
import subprocess
from dataclasses import dataclass

from .coords import Rect

try:  # macOS only; the rest of the app still imports elsewhere.
    import Quartz
    from AppKit import NSApplicationActivateIgnoringOtherApps, NSRunningApplication

    HAVE_QUARTZ = True
except Exception:  # pragma: no cover - non-macOS development machines
    Quartz = None
    NSRunningApplication = None
    NSApplicationActivateIgnoringOtherApps = 0
    HAVE_QUARTZ = False

DEFAULT_HINTS = ("roblox",)


def _hints() -> tuple[str, ...]:
    extra = os.environ.get("CAPYMACRO_WINDOW", "").strip().lower()
    return (extra,) + DEFAULT_HINTS if extra else DEFAULT_HINTS


@dataclass(frozen=True)
class GameWindow:
    rect: Rect
    pid: int
    owner: str


def _windows() -> list[dict]:
    if not HAVE_QUARTZ:
        return []
    # Every window, not just this Space: Roblox is often fullscreen on its own
    # desktop, and an on-screen-only listing would report "not found".
    options = Quartz.kCGWindowListOptionAll | Quartz.kCGWindowListExcludeDesktopElements
    return list(Quartz.CGWindowListCopyWindowInfo(options, Quartz.kCGNullWindowID) or [])


def list_windows() -> list[str]:
    """Owner and size of the big on-screen windows, for diagnostics."""
    found: list[str] = []
    for info in _windows():
        if int(info.get("kCGWindowLayer", 0)) != 0:
            continue
        bounds = info.get("kCGWindowBounds") or {}
        width = int(round(float(bounds.get("Width", 0))))
        height = int(round(float(bounds.get("Height", 0))))
        if width < 320 or height < 240:
            continue
        owner = str(info.get("kCGWindowOwnerName") or "?")
        label = f"{owner} {width}×{height}"
        if label not in found:
            found.append(label)
        if len(found) >= 12:
            break
    return found


def find_game_window() -> GameWindow | None:
    """Return the biggest Roblox window, on or off the current Space."""
    names = _hints()
    best: tuple[int, GameWindow] | None = None

    for info in _windows():
        owner = str(info.get("kCGWindowOwnerName") or "")
        if not any(hint in owner.lower() for hint in names):
            continue
        if int(info.get("kCGWindowLayer", 0)) != 0:
            continue
        bounds = info.get("kCGWindowBounds") or {}
        width = int(round(float(bounds.get("Width", 0))))
        height = int(round(float(bounds.get("Height", 0))))
        if width < 320 or height < 240:
            continue
        rect = Rect(
            int(round(float(bounds.get("X", 0)))),
            int(round(float(bounds.get("Y", 0)))),
            width,
            height,
        )
        candidate = GameWindow(
            rect=rect, pid=int(info.get("kCGWindowOwnerPID", 0)), owner=owner
        )
        area = width * height
        if best is None or area > best[0]:
            best = (area, candidate)

    return best[1] if best is not None else None


def activate(pid: int) -> bool:
    """Bring Roblox forward so synthetic clicks land on it."""
    if not HAVE_QUARTZ or not pid:
        return False
    app = NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
    if app is None:
        return False
    return bool(app.activateWithOptions_(NSApplicationActivateIgnoringOtherApps))


def scale_at(x: float, y: float) -> float:
    """Pixel-per-point ratio of the display containing (x, y).

    mss captures physical pixels while Quartz and CGEvent speak points, so
    screenshots are requested at this scale and resized back.
    """
    if not HAVE_QUARTZ:
        return 1.0

    try:
        _, displays = Quartz.CGGetActiveDisplayList(16, None, None)[:2]
    except Exception:  # pragma: no cover - defensive
        return 1.0

    for display in displays:
        bounds = Quartz.CGDisplayBounds(display)
        origin = bounds.origin
        size = bounds.size
        if origin.x <= x < origin.x + size.width and origin.y <= y < origin.y + size.height:
            point_width = float(size.width)
            pixel_width = float(Quartz.CGDisplayPixelsWide(display))
            if point_width > 0 and pixel_width > 0:
                return pixel_width / point_width
    return 1.0


def open_url(url: str) -> bool:
    """Open a private-server deep link in the default browser."""
    if not url:
        return False
    try:
        subprocess.Popen(["open", url], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False
