"""Asking macOS for Screen Recording and Accessibility.

Both permissions are granted to the app that runs CapyMacro (Terminal, iTerm or
the Python interpreter). The functions here answer "do we have it?" and, more
importantly, trigger the system prompt so the app actually appears in the
System Settings list — a permission that was never requested is not listed.
"""

from __future__ import annotations

import os
import subprocess

try:  # macOS only
    import Quartz
except Exception:  # pragma: no cover - non-macOS development machines
    Quartz = None

try:  # provided by pyobjc-framework-ApplicationServices
    from ApplicationServices import (
        AXIsProcessTrusted,
        AXIsProcessTrustedWithOptions,
        kAXTrustedCheckOptionPrompt,
    )

    HAVE_ACCESSIBILITY_API = True
except Exception:  # pragma: no cover - macOS without that pyobjc framework
    try:
        import ctypes

        _AX = ctypes.cdll.LoadLibrary(
            "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices"
        )
        _AX.AXIsProcessTrusted.restype = ctypes.c_bool
        AXIsProcessTrusted = _AX.AXIsProcessTrusted
        AXIsProcessTrustedWithOptions = None
        kAXTrustedCheckOptionPrompt = None
        HAVE_ACCESSIBILITY_API = True
    except Exception:
        AXIsProcessTrusted = None
        AXIsProcessTrustedWithOptions = None
        kAXTrustedCheckOptionPrompt = None
        HAVE_ACCESSIBILITY_API = False

ACCESSIBILITY_PANE = "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
SCREEN_PANE = "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture"
INPUT_PANE = "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent"

# macOS protects these switches with SIP: no command or script can grant them.
# These only open the right pane so the switch is one click away.
PANE_COMMANDS = (
    f'open "{SCREEN_PANE}"\n'
    f'open "{ACCESSIBILITY_PANE}"\n'
    f'open "{INPUT_PANE}"'
)


def accessibility_granted() -> bool | None:
    """True/False when it can be checked, None when unknown (non-macOS)."""
    if AXIsProcessTrusted is None:
        return None
    try:
        return bool(AXIsProcessTrusted())
    except Exception:
        return None


def request_accessibility() -> bool | None:
    """Show the macOS prompt and add this app to the Accessibility list."""
    if AXIsProcessTrustedWithOptions is None or kAXTrustedCheckOptionPrompt is None:
        return accessibility_granted()
    try:
        return bool(
            AXIsProcessTrustedWithOptions({kAXTrustedCheckOptionPrompt: True})
        )
    except Exception:
        return accessibility_granted()


def screen_recording_granted() -> bool | None:
    if Quartz is None:
        return None
    check = getattr(Quartz, "CGPreflightScreenCaptureAccess", None)
    if check is None:
        return None
    try:
        return bool(check())
    except Exception:
        return None


def input_monitoring_granted() -> bool | None:
    """Input Monitoring (needed for a global key listener on macOS 10.15+)."""
    if Quartz is None:
        return None
    check = getattr(Quartz, "CGPreflightListenEventAccess", None)
    if check is None:
        return None
    try:
        return bool(check())
    except Exception:
        return None


def request_input_monitoring() -> bool | None:
    if Quartz is None:
        return None
    request = getattr(Quartz, "CGRequestListenEventAccess", None)
    if request is None:
        return input_monitoring_granted()
    try:
        return bool(request())
    except Exception:
        return input_monitoring_granted()


def request_screen_recording() -> bool | None:
    if Quartz is None:
        return None
    request = getattr(Quartz, "CGRequestScreenCaptureAccess", None)
    if request is None:
        return screen_recording_granted()
    try:
        return bool(request())
    except Exception:
        return screen_recording_granted()


def request_all() -> None:
    """Ask for all three, which is what makes them show up in System Settings."""
    request_accessibility()
    request_screen_recording()
    request_input_monitoring()


def open_settings(pane: str = ACCESSIBILITY_PANE) -> None:
    try:
        subprocess.Popen(
            ["open", pane], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
        )
    except Exception:
        pass


def reveal(path) -> None:
    """Show a file or folder in Finder."""
    try:
        subprocess.Popen(
            ["open", "-R", str(path)],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        pass


def host_app() -> str:
    """The app macOS will list, based on how CapyMacro was started."""
    if os.environ.get("PYCHARM_HOSTED"):
        return "PyCharm"

    program = os.environ.get("TERM_PROGRAM", "").strip()
    lowered = program.lower()
    if lowered in ("iterm.app", "iterm2", "iterm"):
        return "iTerm"
    if lowered in ("vscode", "vscode-insiders"):
        return "Visual Studio Code"
    if program:
        return program
    return "Terminal (when launched with launch.command)"


def describe(granted: bool | None) -> str:
    if granted is None:
        return "cannot be checked on this machine"
    return "granted" if granted else "not granted yet"
