"""Run engines: Infinite gem farm, Summer event and Dungeon runs.

Everything is screen-driven. Menu buttons the template pack does not cover are
replayed from the points you record in the app; in-run decisions use the shipped
detection images plus Apple Vision OCR.
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable

from .. import keys, vision, window
from . import captcha, mapscan, onscreen
from .assets import GameView, Hit, click_at


class FarmError(RuntimeError):
    pass


def _as_int(value, default: int, low: int | None = None, high: int | None = None) -> int:
    try:
        result = int(float(value))
    except (TypeError, ValueError):
        result = default
    if low is not None:
        result = max(low, result)
    if high is not None:
        result = min(high, result)
    return result


def _as_float(value, default: float, low: float | None = None) -> float:
    try:
        result = float(value)
    except (TypeError, ValueError):
        result = default
    if low is not None:
        result = max(low, result)
    return result


def _as_bool(value, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return bool(value)
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in ("1", "true", "yes", "on"):
            return True
        if lowered in ("0", "false", "no", "off", ""):
            return False
    return default


def _as_names(value, default: list[str]) -> list[str]:
    if isinstance(value, str):
        items = [item.strip() for item in value.split(",")]
    elif isinstance(value, (list, tuple)):
        items = [str(item).strip() for item in value]
    else:
        return list(default)
    cleaned = [item for item in items if item]
    return cleaned or list(default)


MODES = ("Infinite", "Summer", "Dungeon")

# Seconds between two captcha checks. A click never happens while a prompt is up
# because every click and key press runs the guard first.
GUARD_INTERVAL = 1.25

DEFAULT_DUNGEON_ROOMS = ["chests-title", "shop-title", "shrine-title", "boss-label"]
DEFAULT_DUNGEON_SHRINES = [
    "shrine-vitality",
    "shrine-armor",
    "shrine-burst",
    "shrine-eruption",
    "shrine-frenzy",
    "shrine-vampirism",
    "shrine-chaos",
]
DEFAULT_DUNGEON_SHOP = ["shop-philosopher-stone", "shop-shimmering-fragment", "shop-stormbringer"]


@dataclass
class Placement:
    slot: int = 1
    x: float = 0.5
    y: float = 0.5
    upgrades: int = 2

    def to_dict(self) -> dict:
        return {"slot": self.slot, "x": round(self.x, 5), "y": round(self.y, 5), "upgrades": self.upgrades}

    @classmethod
    def from_dict(cls, data: dict) -> "Placement":
        try:
            return cls(
                slot=max(1, min(6, int(data.get("slot", 1)))),
                x=min(1.0, max(0.0, float(data.get("x", 0.5)))),
                y=min(1.0, max(0.0, float(data.get("y", 0.5)))),
                upgrades=max(0, min(20, int(data.get("upgrades", 0)))),
            )
        except (TypeError, ValueError):
            return cls()


@dataclass
class UnitSettings:
    """One unit card: slot 1-6 with its order, copies and upgrade cap."""

    slot: int = 1
    enabled: bool = True
    place_priority: int = 1
    upgrade_priority: int = 1
    placements: int = 0  # 0 places every recorded position for the unit
    upgrade_limit: int = 0
    enable_upgrade_limit: bool = False
    auto_ability: bool = False
    hill: bool = False

    def to_dict(self) -> dict:
        return {
            "slot": self.slot,
            "enabled": self.enabled,
            "place_priority": self.place_priority,
            "upgrade_priority": self.upgrade_priority,
            "placements": self.placements,
            "upgrade_limit": self.upgrade_limit,
            "enable_upgrade_limit": self.enable_upgrade_limit,
            "auto_ability": self.auto_ability,
            "hill": self.hill,
        }

    @classmethod
    def from_dict(cls, data: dict, slot: int = 1) -> "UnitSettings":
        slot = _as_int(data.get("slot"), slot, low=1, high=6)
        return cls(
            slot=slot,
            enabled=_as_bool(data.get("enabled"), True),
            place_priority=_as_int(data.get("place_priority"), slot, low=1, high=6),
            upgrade_priority=_as_int(data.get("upgrade_priority"), slot, low=1, high=6),
            placements=_as_int(data.get("placements"), 0, low=0, high=30),
            upgrade_limit=_as_int(data.get("upgrade_limit"), 0, low=0, high=30),
            enable_upgrade_limit=_as_bool(data.get("enable_upgrade_limit"), False),
            auto_ability=_as_bool(data.get("auto_ability"), False),
            hill=_as_bool(data.get("hill"), False),
        )


def default_units() -> list[UnitSettings]:
    return [
        UnitSettings(slot=slot, place_priority=slot, upgrade_priority=slot)
        for slot in range(1, 7)
    ]


@dataclass
class FarmConfig:
    mode: str = "Infinite"
    map_name: str = "Ruined City"
    auto_map: bool = False  # read the stage name off the screen instead of trusting the picker
    runs: int = 0  # 0 = until stopped
    vote_wave: int = 6
    vote_timeout: float = 1200.0
    fallback_vote_seconds: float = 240.0
    result_timeout: float = 600.0
    private_server: str = ""
    webhook: str = ""
    dry_run: bool = False
    captcha_guard: bool = True
    auto_play: bool = True  # press the Roblox Play button when it appears
    auto_reconnect: bool = True  # rejoin when the game drops the connection
    auto_matchmaking: bool = True  # Summer: press the Matchmaking button
    queue_walk_seconds: float = 0.0  # hold W for this long after Play, to walk into the queue
    return_to_lobby: bool = True  # click Lobby after each match, then Play again
    start_hotkey: str = "]"  # global start/stop key
    ability_key: str = ""  # pressed for units with Auto ability ticked

    # Win/loss calculator, kept across sessions
    wins_total: int = 0
    losses_total: int = 0

    units: list[UnitSettings] = field(default_factory=default_units)

    # Dungeon decisions
    dungeon_rooms: list[str] = field(default_factory=lambda: list(DEFAULT_DUNGEON_ROOMS))
    dungeon_shrines: list[str] = field(default_factory=lambda: list(DEFAULT_DUNGEON_SHRINES))
    dungeon_shop: list[str] = field(default_factory=lambda: list(DEFAULT_DUNGEON_SHOP))
    dungeon_shop_limit: int = 2
    dungeon_chests: str = "End"  # "End" saves chests for the end, "Now" opens them as they appear
    dungeon_heart_stop: int = 1

    start_clicks: list[list[float]] = field(default_factory=list)
    vote_clicks: list[list[float]] = field(default_factory=list)
    placements: list[Placement] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "mode": self.mode,
            "map_name": self.map_name,
            "auto_map": self.auto_map,
            "runs": self.runs,
            "vote_wave": self.vote_wave,
            "vote_timeout": self.vote_timeout,
            "fallback_vote_seconds": self.fallback_vote_seconds,
            "result_timeout": self.result_timeout,
            "private_server": self.private_server,
            "webhook": self.webhook,
            "dry_run": self.dry_run,
            "captcha_guard": self.captcha_guard,
            "auto_play": self.auto_play,
            "auto_reconnect": self.auto_reconnect,
            "auto_matchmaking": self.auto_matchmaking,
            "queue_walk_seconds": self.queue_walk_seconds,
            "return_to_lobby": self.return_to_lobby,
            "start_hotkey": self.start_hotkey,
            "ability_key": self.ability_key,
            "wins_total": self.wins_total,
            "losses_total": self.losses_total,
            "units": [unit.to_dict() for unit in self.units],
            "dungeon_rooms": list(self.dungeon_rooms),
            "dungeon_shrines": list(self.dungeon_shrines),
            "dungeon_shop": list(self.dungeon_shop),
            "dungeon_shop_limit": self.dungeon_shop_limit,
            "dungeon_chests": self.dungeon_chests,
            "dungeon_heart_stop": self.dungeon_heart_stop,
            "start_clicks": [[round(x, 5), round(y, 5)] for x, y in self.start_clicks],
            "vote_clicks": [[round(x, 5), round(y, 5)] for x, y in self.vote_clicks],
            "placements": [placement.to_dict() for placement in self.placements],
        }

    @classmethod
    def from_dict(cls, data: dict) -> "FarmConfig":
        config = cls()
        mode = str(data.get("mode", config.mode))
        config.mode = mode if mode in MODES else "Infinite"
        config.map_name = str(data.get("map_name", config.map_name))
        config.auto_map = _as_bool(data.get("auto_map"), False)
        config.runs = _as_int(data.get("runs"), 0, low=0, high=9999)
        config.vote_wave = _as_int(data.get("vote_wave"), 6, low=1, high=100)
        config.vote_timeout = _as_float(data.get("vote_timeout"), 1200.0, low=30.0)
        config.fallback_vote_seconds = _as_float(data.get("fallback_vote_seconds"), 240.0, low=5.0)
        config.result_timeout = _as_float(data.get("result_timeout"), 600.0, low=30.0)
        config.private_server = str(data.get("private_server", "") or "")
        config.webhook = str(data.get("webhook", "") or "")
        config.dry_run = _as_bool(data.get("dry_run"), False)
        config.captcha_guard = _as_bool(data.get("captcha_guard"), True)
        config.auto_play = _as_bool(data.get("auto_play"), True)
        config.auto_reconnect = _as_bool(data.get("auto_reconnect"), True)
        config.auto_matchmaking = _as_bool(data.get("auto_matchmaking"), True)
        config.queue_walk_seconds = _as_float(data.get("queue_walk_seconds"), 0.0, low=0.0)
        config.return_to_lobby = _as_bool(data.get("return_to_lobby"), True)
        hotkey = str(data.get("start_hotkey", config.start_hotkey) or "").strip()
        config.start_hotkey = hotkey or "]"
        config.ability_key = str(data.get("ability_key", "") or "").strip()
        config.wins_total = _as_int(data.get("wins_total"), 0, low=0)
        config.losses_total = _as_int(data.get("losses_total"), 0, low=0)

        stored = {
            _as_int(item.get("slot"), 0, low=0, high=6): item
            for item in data.get("units") or []
            if isinstance(item, dict)
        }
        config.units = [
            UnitSettings.from_dict(stored[slot], slot) if slot in stored else UnitSettings(slot=slot, place_priority=slot, upgrade_priority=slot)
            for slot in range(1, 7)
        ]

        config.dungeon_rooms = _as_names(data.get("dungeon_rooms"), DEFAULT_DUNGEON_ROOMS)
        config.dungeon_shrines = _as_names(data.get("dungeon_shrines"), DEFAULT_DUNGEON_SHRINES)
        config.dungeon_shop = _as_names(data.get("dungeon_shop"), DEFAULT_DUNGEON_SHOP)
        config.dungeon_shop_limit = _as_int(data.get("dungeon_shop_limit"), 2, low=0, high=20)
        chests = str(data.get("dungeon_chests", "End"))
        config.dungeon_chests = "Now" if chests.lower() == "now" else "End"
        config.dungeon_heart_stop = _as_int(data.get("dungeon_heart_stop"), 1, low=0, high=10)

        for key in ("start_clicks", "vote_clicks"):
            points = []
            for point in data.get(key) or []:
                try:
                    points.append([min(1.0, max(0.0, float(point[0]))), min(1.0, max(0.0, float(point[1])))])
                except (TypeError, ValueError, IndexError):
                    continue
            setattr(config, key, points)

        config.placements = [Placement.from_dict(item) for item in data.get("placements") or [] if isinstance(item, dict)]
        return config


class FarmEngine:
    """One background engine, three run types."""

    def __init__(
        self,
        config: FarmConfig,
        view: GameView | None = None,
        on_log: Callable[[str], None] | None = None,
        on_stats: Callable[[dict], None] | None = None,
        on_finished: Callable[[bool, str], None] | None = None,
    ):
        self.config = config
        self.view = view or GameView()
        self._log_cb = on_log or (lambda message: None)
        self._stats_cb = on_stats or (lambda stats: None)
        self._finished_cb = on_finished or (lambda ok, message: None)

        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._mouse = None
        self._next_guard = 0.0
        self._in_guard = False
        self._captcha_shown = False
        self._vision_warned = False
        self._map_warned = False
        self._cooldowns: dict[str, float] = {}
        self._hearts_unreadable = False
        self._next_heart_check = 0.0
        self._shop_bought = 0
        self._shrine_cooldown = 0.0
        self._next_disconnect_check = 0.0
        self._ability_warned = False
        self._walk_hint_shown = False

        self.runs = 0
        self.wins = 0
        self.losses = 0
        self.purchases = 0
        self.started_at = time.time()

    # ------------------------------------------------------------------ public

    def start(self) -> None:
        if self.is_running():
            return
        self._stop.clear()
        self.started_at = time.time()
        self._thread = threading.Thread(target=self._run, name="capymacro-farm", daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def is_running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    @property
    def dry_run(self) -> bool:
        return bool(self.config.dry_run)

    # -------------------------------------------------------------------- loop

    def _run(self) -> None:
        try:
            self._loop()
        except FarmError as exc:
            self._finished_cb(False, str(exc))
        except Exception as exc:  # keep the UI alive on unexpected failures
            self._finished_cb(False, f"Stopped after an error: {exc}")
        else:
            self._finished_cb(True, "Stopped." if self._stop.is_set() else "Finished.")
        finally:
            self._thread = None

    def _loop(self) -> None:
        if not self.view.target():
            raise FarmError("Roblox window not found. Open Anime Adventures and keep its window visible.")
        if not self.config.placements and not self.config.start_clicks and not self.config.auto_play:
            raise FarmError("Nothing configured yet: add start clicks and unit placements first.")

        attempt = 0
        while not self._stop.is_set():
            attempt += 1
            self._log(
                f"Run {attempt}"
                + (f"/{self.config.runs}" if self.config.runs else "")
                + f" · {self.config.map_name}"
            )
            self._push_stats()

            self._ensure_in_game()
            self._start_map()
            self._detect_map()
            self._place_units()
            self._guard()

            if self.config.mode == "Dungeon":
                completed = self._play_dungeon()
            elif self.config.mode == "Summer":
                completed = self._play_summer()
            else:
                completed = self._play_infinite()

            if completed:
                self._finish_run()
                self.runs += 1
            elif not self._stop.is_set():
                self._log("Run was interrupted — starting again.")
            self._push_stats()

            if self.config.runs and self.runs >= self.config.runs:
                return
            self._pause(2.0)

    # ------------------------------------------------------------------- steps

    def _ensure_in_game(self) -> None:
        """Notice a disconnect dialog and rejoin before starting the next run."""
        if not self.config.auto_reconnect:
            reconnect = self.view.wait_for(["reconnect"], timeout=0.6, stop=self._stop, on_tick=self._guard)
            if reconnect is not None:
                self._recover_connection()
            return

        frame = self.view.frame()
        notice = onscreen.disconnected(frame) if frame is not None else None
        if notice is None:
            hit = self.view.locate("reconnect") or self.view.locate("title")
            notice = hit.name if hit is not None else None
        if notice is None:
            return

        self._log(f"Disconnect notice on screen ({notice}) — rejoining.")
        self._recover_connection()

    def _recover_connection(self) -> None:
        """Click Reconnect, reopen the private server if needed, and press Play."""
        self._log("Disconnected — reconnecting…")

        button = self.view.locate("reconnect")
        if button is None:
            button = onscreen.reconnect_button(self.view)
        if button is not None:
            self._click_hit(button)
            self._log("Clicked Reconnect.")
            self._pause(6.0)
        else:
            self._log("No Reconnect button on screen.")

        if self.config.private_server and not self.dry_run:
            window.open_url(self.config.private_server)
            self._log("Opened the private server link.")
            self._pause(12.0)
        else:
            self._pause(4.0)

        self._wait_until_gone("reconnect", timeout=90.0)
        if self.config.auto_play:
            # A successful Reconnect loads straight into the game, so this is a
            # short look: a failed one lands on the experience page with Play.
            self._press_play(timeout=12.0)

    def _press_button(self, finder, label: str, timeout: float) -> bool:
        """Click the first short on-screen label a finder recognises."""
        deadline = time.monotonic() + max(1.0, timeout)
        while not self._stop.is_set():
            self._guard()
            frame = self.view.frame()
            if frame is not None:
                hit = finder(self.view, frame)
                if hit is not None:
                    self._log(f"{label} button found (“{hit.name}”) — pressing it.")
                    self._click_hit(hit)
                    self._pause(3.0)
                    return True
            if time.monotonic() >= deadline:
                break
            self._pause(1.0)
        return False

    def _press_matchmaking(self, timeout: float = 8.0) -> bool:
        """Summer: click a Matchmaking button in the lobby, when there is one."""
        if self._press_button(onscreen.matchmaking_button, "Matchmaking", timeout):
            return True
        self._log("Auto matchmaking: no Matchmaking button on screen — continuing.")
        return False

    def _press_find_match(self, timeout: float = 12.0) -> bool:
        """Summer: click Find Match in the "Join Matchmaking?" panel.

        Play Here sits in the same panel and starts a private run, so only the
        Find Match label queues; the panel title is skipped by name.
        """
        if self._press_button(onscreen.find_match_button, "Find Match", timeout):
            return True
        self._log("Find Match button not found — the queue panel may have closed already.")
        return False

    def _press_play(self, timeout: float = 30.0) -> bool:
        """Find the Roblox Play button with OCR and press it."""
        if self._press_button(onscreen.play_button, "Play", timeout):
            return True

        self._log("Auto play: no Play button on screen — assuming the run is already open.")
        frame = self.view.frame()
        if frame is not None:
            if not vision.available():
                self._log("Auto play: Apple Vision OCR is unavailable — check Screen Recording permission.")
            else:
                seen = vision.read_text(frame, fast=True, max_width=1280)
                preview = " | ".join(seen[:10]) if seen else "(no text read)"
                self._log(f"Auto play: OCR saw: {preview}")
        return False

    def _watch_disconnect(self, frame) -> bool:
        """Mid-run check: a disconnect notice means this run is over."""
        if not self.config.auto_reconnect:
            return False
        now = time.monotonic()
        if now < self._next_disconnect_check:
            return False
        self._next_disconnect_check = now + 4.0

        if (
            onscreen.disconnected(frame) is None
            and not self._visible(frame, "title")
            and not self._visible(frame, "reconnect")
        ):
            return False

        self._log("Disconnected mid-run — the run is over, rejoining.")
        self._recover_connection()
        return True

    def _start_map(self) -> None:
        if self.config.start_clicks:
            for index, (fx, fy) in enumerate(self.config.start_clicks, start=1):
                if self._stop.is_set():
                    return
                self._log(f"Start click {index}/{len(self.config.start_clicks)}")
                self._click_relative(fx, fy)
                self._pause(1.2)
            self._pause(4.0)
        elif not self.config.auto_play:
            self._log("No start clicks set — assuming the run is already open.")
            return

        if not self.config.auto_play:
            return

        # With start clicks recorded, those already open the game: the OCR
        # buttons are a fallback, so they get a short look instead of stalling.
        short = bool(self.config.start_clicks)
        summer = self.config.mode == "Summer" and self.config.auto_matchmaking

        # The queue panel can already be open — left over from the last run, or
        # because you walked in yourself — and it covers the Play button. Queue
        # from it instead of waiting for a click that cannot land.
        if summer and onscreen.queue_dialog_open(self.view.frame()):
            self._log("“Join Matchmaking?” is already open — pressing Find Match.")
            self._press_find_match(timeout=8.0)
            return

        if summer:
            # Some Summer layouts queue from a Matchmaking button in the lobby.
            self._press_matchmaking(timeout=4.0)

        if not self._press_play(timeout=8.0 if short else 30.0):
            if summer and self.config.queue_walk_seconds <= 0:
                self._log(
                    "No Play button found. If you reach the queue by walking, set "
                    "“Walk forward after Play” on the Summer page."
                )
            return

        if self.config.queue_walk_seconds > 0:
            # Play drops you in the lobby: hold W for the set time so the
            # character steps into the queue area. A straight timed walk only.
            self._pause(1.2)
            self._walk_forward(self.config.queue_walk_seconds)
        elif summer and not self._walk_hint_shown:
            self._walk_hint_shown = True
            self._log(
                "Walk forward after Play is off — set it on the Summer page if the "
                "queue needs you to step in."
            )

        if summer:
            self._press_find_match(timeout=12.0)

    def _detect_map(self) -> None:
        """Read the stage name off the loading screen and use the matching config."""
        if not self.config.auto_map:
            return
        if not vision.available():
            if not self._map_warned:
                self._map_warned = True
                self._log(
                    "Auto map needs Apple Vision OCR, which is unavailable — "
                    f"staying on {self.config.map_name}."
                )
            return

        match = None
        for _attempt in range(3):
            if self._stop.is_set():
                return
            match = mapscan.read_map(self.view, mode=self.config.mode)
            if match is not None:
                break
            if self._stop.wait(1.5):
                return

        if match is None:
            self._log(f"Auto map: no map name on screen — staying on {self.config.map_name}.")
            return

        self.config.map_name = match.config.map_name
        note = ""
        if match.config.mode.lower() != self.config.mode.lower():
            note = f" — that stage's config is {match.config.mode}, but the mode is {self.config.mode}"
        self._log(
            f"Auto map: {match.config.map_name} (read “{match.text.strip()}”, "
            f"{match.score:.0%} match){note}"
        )

    def _place_units(self) -> None:
        """Place units by Placement priority, then upgrade by Upgrade priority."""
        if not self.config.placements:
            return
        rect = self.view.rect()
        if rect is None:
            raise FarmError("Lost the Roblox window while placing units.")

        units = {unit.slot: unit for unit in self.config.units}
        by_slot: dict[int, list[Placement]] = {}
        for placement in self.config.placements:
            by_slot.setdefault(placement.slot, []).append(placement)

        placed: list[tuple[int, int, int, int]] = []  # slot, x, y, upgrades
        ordered = sorted(by_slot, key=lambda slot: (units.get(slot, UnitSettings(slot=slot)).place_priority, slot))

        for slot in ordered:
            if self._stop.is_set():
                return
            unit = units.get(slot) or UnitSettings(slot=slot)
            if not unit.enabled:
                self._log(f"Unit {slot} is disabled — skipped.")
                continue

            spots = by_slot[slot]
            wanted = unit.placements if unit.placements > 0 else len(spots)
            for index, placement in enumerate(spots[:wanted], start=1):
                if self._stop.is_set():
                    return
                x, y = rect.to_absolute(placement.x, placement.y)
                self._log(f"Place unit {slot} ({index}/{min(wanted, len(spots))}) at ({x}, {y})")
                self._press(str(slot))
                self._pause(0.4)
                self._click_at(x, y)
                self._pause(0.6)
                placed.append((slot, x, y, placement.upgrades))
                self._auto_ability(unit)
                self._pause(0.4)

        for slot in sorted(by_slot, key=lambda slot: (units.get(slot, UnitSettings(slot=slot)).upgrade_priority, slot)):
            if self._stop.is_set():
                return
            unit = units.get(slot) or UnitSettings(slot=slot)
            if not unit.enabled:
                continue
            budget = unit.upgrade_limit if unit.enable_upgrade_limit else None
            for spot_slot, x, y, upgrades in [item for item in placed if item[0] == slot]:
                if self._stop.is_set():
                    return
                if upgrades <= 0:
                    continue
                if budget is not None and budget <= 0:
                    break
                count = upgrades if budget is None else min(upgrades, budget)
                self._log(f"Upgrade unit {slot} at ({x}, {y}) ×{count}")
                self._press(str(slot))
                self._pause(0.3)
                self._click_at(x, y)
                self._pause(0.4)
                self._upgrade(count)
                if budget is not None:
                    budget -= count

    def _walk_forward(self, seconds: float) -> None:
        """Hold W for a moment: enough to step into a queue zone, nothing more."""
        seconds = max(0.0, float(seconds))
        if seconds <= 0:
            return
        self._log(f"Walking forward for {seconds:g}s into the queue area.")
        if self.dry_run:
            self._log(f"dry run: hold w for {seconds:g}s")
            return
        if not keys.available():
            raise FarmError("Keyboard control is unavailable — grant Accessibility permission.")

        self._guard()
        self.view.focus()
        if not keys.key_down("w"):
            raise FarmError("Could not hold W — is Accessibility granted?")
        try:
            self._pause(seconds)
        finally:
            keys.key_up("w")

    def _auto_ability(self, unit: UnitSettings) -> None:
        if not unit.auto_ability:
            return
        key = self.config.ability_key.strip()
        if not key:
            if not self._ability_warned:
                self._ability_warned = True
                self._log(
                    "Auto ability is ticked but no Ability key is set — add one under "
                    "Connection → Ability key."
                )
            return
        self._press(key)
        self._pause(0.3)

    def _upgrade(self, times: int) -> None:
        for _ in range(times):
            if self._stop.is_set():
                return
            button = self.view.locate("upgrade-max-button")
            if button is not None:
                self._click_hit(button)
            else:
                self._log("Upgrade button not found on screen — skipping upgrades.")
                return
            self._pause(0.5)

    # ------------------------------------------------------------------ modes

    def _play_infinite(self) -> bool:
        if not vision.available():
            self._log(f"OCR unavailable: waiting {self.config.fallback_vote_seconds:g}s before voting.")
            self._pause(self.config.fallback_vote_seconds)
        else:
            self._log(f"Waiting for wave {self.config.vote_wave}…")
            deadline = time.monotonic() + self.config.vote_timeout
            last = 0
            while not self._stop.is_set():
                self._guard()
                frame = self.view.frame()
                if frame is not None:
                    if self._watch_disconnect(frame):
                        return False
                    wave = vision.wave_number(frame)
                    if wave is not None and wave != last:
                        last = wave
                        self._log(f"Wave {wave}")
                    if wave is not None and wave >= self.config.vote_wave:
                        break
                if time.monotonic() >= deadline:
                    raise FarmError(f"Wave {self.config.vote_wave} was not reached in time.")
                if self._stop.wait(1.5):
                    return False

        vote = self.view.wait_for(["vote-start"], timeout=30.0, stop=self._stop, on_tick=self._guard)
        if vote is None:
            self._log("Vote button not found — stopping this run.")
            return False
        self._click_hit(vote)
        self._pause(0.8)
        for fx, fy in self.config.vote_clicks:
            if self._stop.is_set():
                return False
            self._click_relative(fx, fy)
            self._pause(0.8)
        return True

    def _play_summer(self) -> bool:
        self._log("Summer run started — waiting for the result…")
        deadline = time.monotonic() + self.config.result_timeout
        while not self._stop.is_set():
            self._guard()
            frame = self.view.frame()
            if frame is not None:
                if self._watch_disconnect(frame):
                    return False
                if self._visible_any(frame, ("victory", "defeat", "victory-title", "death-title")) is not None:
                    return True
            if time.monotonic() >= deadline:
                raise FarmError("The Summer run did not finish in time.")
            self._pause(1.0)
        return False

    def _play_dungeon(self) -> bool:
        self._log("Dungeon run started — following your room, shrine and shop priorities…")
        deadline = time.monotonic() + self.config.result_timeout
        chests_now = self.config.dungeon_chests.strip().lower() == "now"
        self._cooldowns.clear()

        while not self._stop.is_set():
            self._guard()

            frame = self.view.frame()
            if frame is None:
                self._pause(0.6)
                continue

            if self._watch_disconnect(frame):
                return False

            if self._visible_any(frame, ("victory-title", "death-title")) is not None:
                self._dungeon_open_chests()
                return True

            self._dungeon_low_hearts(frame)

            if chests_now:
                self._drain_rewards()

            if self._dungeon_shop(frame):
                continue

            if self._dungeon_shrine(frame):
                continue

            room = self._next_room(frame)
            if room is not None:
                self._log(f"Room: {room.name}")
                self._choose(room)
                continue

            advance = self._visible_any(frame, ("next-room", "next-level", "next-label", "reward-continue"))
            if advance is not None and self._ready(advance.name):
                self._log(f"Advancing ({advance.name})")
                self._choose(advance)
                continue

            if time.monotonic() >= deadline:
                raise FarmError(
                    "The dungeon run did not finish in time. Check the room/shrine/shop names "
                    "against templates/AA, or raise the dungeon timeout."
                )
            self._pause(0.7)

        return False

    def _dungeon_shop(self, frame) -> bool:
        """Buy from an open dungeon shop, then leave it. True when a shop was handled."""
        if self.config.dungeon_shop_limit <= 0:
            return False
        visible = [name for name in self.config.dungeon_shop if self._visible(frame, name)]
        if not visible:
            self._shop_bought = 0  # shop is closed; the next one starts with a fresh budget
            return False

        for name in visible:
            if self._stop.is_set() or self._shop_bought >= self.config.dungeon_shop_limit:
                break
            hit = self.view.locate(name)
            if hit is None:
                continue
            self._log(f"Shop: buying {name}")
            self._click_hit(hit)
            self.purchases += 1
            self._shop_bought += 1
            self._push_stats()
            self._pause(1.2)

        self._log("Shop: leaving.")
        self._leave_screen(("next-room", "next-label", "reward-continue", "leaderboard-close"))
        return True

    def _dungeon_shrine(self, frame) -> bool:
        """Take the first preferred shrine visible on a shrine screen."""
        if time.monotonic() < self._shrine_cooldown:
            return False
        for name in self.config.dungeon_shrines:
            if name == "shrine-title":
                continue
            hit = self.view.locate(name, frame=frame)
            if hit is None:
                continue
            if self._stop.is_set():
                return False
            self._log(f"Shrine: taking {name}")
            self._click_hit(hit)
            self._shrine_cooldown = time.monotonic() + 10.0
            self._pause(1.4)
            return True
        return False

    def _next_room(self, frame) -> Hit | None:
        """First room label in priority order that is off cooldown."""
        for name in self.config.dungeon_rooms:
            if not self._ready(name):
                continue
            hit = self.view.locate(name, frame=frame)
            if hit is not None:
                return hit
        return None

    def _choose(self, hit: Hit) -> None:
        """Click a room/advance label and stop retrying it for a moment."""
        self._cooldowns[hit.name] = time.monotonic() + 5.0
        self._click_hit(hit)
        self._pause(1.4)

    def _drain_rewards(self) -> None:
        """Open reward panels as they appear (Chests: Now)."""
        for _ in range(4):
            if self._stop.is_set():
                return
            hit = self.view.locate("reward-continue")
            if hit is None:
                return
            self._click_hit(hit)
            self._pause(1.0)

    def _dungeon_open_chests(self) -> None:
        """After a dungeon ends, click through every reward / chest panel."""
        for _ in range(8):
            if self._stop.is_set():
                return
            hit = self.view.wait_for(
                ["chests-title", "reward-continue", "leaderboard-close"],
                timeout=5.0,
                stop=self._stop,
                on_tick=self._guard,
            )
            if hit is None:
                return
            self._click_hit(hit)
            self._pause(1.2)

    def _leave_screen(self, names, timeout: float = 6.0) -> bool:
        hit = self.view.wait_for(names, timeout=timeout, stop=self._stop, on_tick=self._guard)
        if hit is None:
            self._log("No way out of that screen was found — close it in Roblox and the macro will carry on.")
            return False
        self._click_hit(hit)
        self._pause(1.0)
        return True

    # ----------------------------------------------------------------- result

    def _finish_run(self) -> None:
        result = self.view.wait_for(
            ["defeat", "victory", "victory-title", "death-title"],
            timeout=self.config.result_timeout,
            stop=self._stop,
            on_tick=self._guard,
        )
        if result is None:
            raise FarmError("The match result never appeared.")

        if result.name in ("victory", "victory-title"):
            self.wins += 1
            self._log("Victory.")
        else:
            self.losses += 1
            self._log("Defeat — as expected." if self.config.mode == "Infinite" else "Defeat.")

        self._pause(1.0)
        for _ in range(4):
            follow_up = self.view.wait_for(
                ["reward-continue", "next-level", "next-room", "next-label", "leaderboard-close", "replay", "retry"],
                timeout=8.0,
                stop=self._stop,
                on_tick=self._guard,
            )
            if follow_up is None:
                break
            self._click_hit(follow_up)
            self._pause(1.2)
            if follow_up.name in ("replay", "retry"):
                break

        if self.config.return_to_lobby and self.config.mode != "Dungeon":
            if not self._press_button(onscreen.lobby_button, "Lobby", timeout=5.0):
                self._log("No Lobby button found — using the start clicks for the next run.")
        self._pause(3.0)

    # ----------------------------------------------------------------- helpers

    def _visible(self, frame, name: str, threshold: float = 0.86) -> bool:
        return self.view.locate(name, frame=frame, threshold=threshold) is not None

    def _visible_any(self, frame, names, threshold: float = 0.86) -> Hit | None:
        for name in names:
            hit = self.view.locate(name, frame=frame, threshold=threshold)
            if hit is not None:
                return hit
        return None

    def _ready(self, name: str) -> bool:
        return time.monotonic() >= self._cooldowns.get(name, 0.0)

    def _dungeon_low_hearts(self, frame) -> None:
        """Pause clicks when the dungeon heart count reaches the configured limit."""
        threshold = self.config.dungeon_heart_stop
        if threshold <= 0:
            return
        now = time.monotonic()
        if now < self._next_heart_check:
            return
        self._next_heart_check = now + 2.0

        if not vision.available():
            return

        hearts = vision.hearts_number(frame)
        if hearts is None:
            if not self._hearts_unreadable:
                self._hearts_unreadable = True
                self._log(
                    "Hearts are not readable on this screen — 'Stop at hearts' stays inactive "
                    "until the dungeon HUD shows a readable heart count."
                )
            return

        self._hearts_unreadable = False
        if hearts > threshold:
            return

        self._log(f"Hearts down to {hearts} — pausing the run until they recover.")
        captcha.notify(
            "CapyMacro paused",
            "Hearts are low. Heal or leave the dungeon; the macro resumes when the count recovers.",
            "Low hearts",
        )
        deadline = time.monotonic() + 300.0
        while not self._stop.is_set():
            if time.monotonic() >= deadline:
                self._log("Hearts did not recover in time — carrying on.")
                return
            if self._stop.wait(3.0):
                return
            frame = self.view.frame()
            if frame is None:
                continue
            if self._visible_any(frame, ("victory-title", "death-title")) is not None:
                return
            hearts = vision.hearts_number(frame)
            if hearts is not None and hearts > threshold:
                self._log(f"Hearts back to {hearts} — resuming.")
                return

    def _guard(self) -> None:
        """Pause input while a human-verification prompt is on screen."""
        if not self.config.captcha_guard or self._in_guard:
            return
        now = time.monotonic()
        if now < self._next_guard:
            return
        self._next_guard = now + GUARD_INTERVAL

        if not vision.available():
            if not self._vision_warned:
                self._vision_warned = True
                self._log("Captcha guard needs Apple Vision OCR, which is unavailable — guard is off.")
            return

        frame = self.view.frame()
        reason = captcha.detect(frame) if frame is not None else None
        if reason is None:
            self._captcha_shown = False
            return

        self._in_guard = True
        try:
            if not self._captcha_shown:
                self._captcha_shown = True
                self._log(
                    "Human verification detected — input paused. "
                    "Solve it in Roblox; the macro resumes when it clears."
                )
                captcha.alert(reason)
            self._wait_out_captcha(reason)
        finally:
            self._in_guard = False
            self._next_guard = time.monotonic() + GUARD_INTERVAL

    def _wait_out_captcha(self, reason: str) -> None:
        """Wait for two consecutive clear screens before touching the game again."""
        clear = 0
        last_alert = time.monotonic()
        while not self._stop.is_set():
            if self._stop.wait(2.0):
                return
            frame = self.view.frame()
            if frame is not None and captcha.detect(frame) is None:
                clear += 1
                if clear >= 2:
                    self._captcha_shown = False
                    self._log("Verification cleared — resuming.")
                    return
            else:
                clear = 0
                if time.monotonic() - last_alert >= 90.0:
                    last_alert = time.monotonic()
                    captcha.alert(reason)

    def _wait_until_gone(self, name: str, timeout: float) -> None:
        deadline = time.monotonic() + timeout
        while not self._stop.is_set() and time.monotonic() < deadline:
            if self.view.locate(name) is None:
                return
            if self._stop.wait(1.0):
                return

    def _click_at(self, x: int, y: int) -> None:
        if self.dry_run:
            self._log(f"dry run: click ({x}, {y})")
            return
        self._guard()
        self.view.focus()
        click_at(x, y, self.view.last_pid)

    def _click_hit(self, hit: Hit) -> None:
        self._click_at(hit.x, hit.y)

    def _click_relative(self, fx: float, fy: float) -> None:
        rect = self.view.rect()
        if rect is None:
            raise FarmError("Lost the Roblox window.")
        x, y = rect.to_absolute(fx, fy)
        self._click_at(x, y)

    def _press(self, key: str) -> None:
        if self.dry_run:
            self._log(f"dry run: press {key}")
            return
        if not keys.available():
            raise FarmError("Keyboard control is unavailable — grant Accessibility permission.")
        if keys.keycode(key) is None:
            self._log(f"Unknown key “{key}” — skipped.")
            return

        self._guard()
        self.view.focus()
        if not keys.press(key):
            raise FarmError(f"Could not press “{key}” — is Accessibility granted?")

    def _pause(self, seconds: float) -> None:
        deadline = time.monotonic() + max(0.0, seconds)
        while not self._stop.is_set():
            self._guard()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return
            if self._stop.wait(min(0.05, remaining)):
                return

    def _log(self, message: str) -> None:
        self._log_cb(message)

    def _push_stats(self) -> None:
        minutes, seconds = divmod(int(time.time() - self.started_at), 60)
        self._stats_cb(
            {
                "runs": self.runs,
                "wins": self.wins,
                "losses": self.losses,
                "purchases": self.purchases,
                "duration": f"{minutes}m {seconds}s",
                "map": self.config.map_name,
            }
        )
