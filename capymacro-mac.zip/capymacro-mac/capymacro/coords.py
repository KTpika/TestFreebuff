"""Window-relative coordinate maths.

Everything the macro stores is a fraction of the game window, so moving or
resizing the window does not break a recording.
"""

from __future__ import annotations

from dataclasses import dataclass


def _clamp01(value: float) -> float:
    if value < 0.0:
        return 0.0
    if value > 1.0:
        return 1.0
    return value


@dataclass(frozen=True)
class Rect:
    """A rectangle in screen points (the same space CGEvent uses)."""

    left: int
    top: int
    width: int
    height: int

    @property
    def right(self) -> int:
        return self.left + self.width

    @property
    def bottom(self) -> int:
        return self.top + self.height

    @property
    def center(self) -> tuple[float, float]:
        return (self.left + self.width / 2.0, self.top + self.height / 2.0)

    def contains(self, x: float, y: float) -> bool:
        return self.left <= x < self.right and self.top <= y < self.bottom

    def to_relative(self, x: float, y: float) -> tuple[float, float]:
        width = self.width or 1
        height = self.height or 1
        return (_clamp01((x - self.left) / width), _clamp01((y - self.top) / height))

    def to_absolute(self, fx: float, fy: float) -> tuple[int, int]:
        x = self.left + _clamp01(fx) * self.width
        y = self.top + _clamp01(fy) * self.height
        return (int(round(x)), int(round(y)))

    def as_list(self) -> list[int]:
        return [self.left, self.top, self.width, self.height]
