"""Click-through overlay that previews a placement pattern on the game window."""

from __future__ import annotations

from PySide6.QtCore import QPoint, QPointF, QRect, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPolygonF
from PySide6.QtWidgets import QWidget

AMBER = QColor(242, 193, 78, 235)
AMBER_DIM = QColor(242, 193, 78, 90)
INK = QColor(24, 22, 18, 230)


class RingPreview(QWidget):
    """Shows where units will land, without capturing clicks or focus."""

    def __init__(self, parent=None):
        super().__init__(
            parent,
            Qt.ToolTip  # always on top, never takes focus
            | Qt.FramelessWindowHint
            | Qt.WindowStaysOnTopHint
            | Qt.WindowTransparentForInput,
        )
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_TransparentForMouseEvents, True)
        self.setAttribute(Qt.WA_ShowWithoutActivating, True)
        self.setFocusPolicy(Qt.NoFocus)
        self._points: list[QPoint] = []
        self._center: QPoint | None = None

    def set_ring(self, points, center, rect: QRect | None) -> None:
        """``points`` and ``center`` are global points; ``rect`` is the game window."""
        if rect is None or not points:
            self.clear_ring()
            return
        self._points = [QPoint(int(x) - rect.left(), int(y) - rect.top()) for x, y in points]
        self._center = (
            QPoint(int(center[0]) - rect.left(), int(center[1]) - rect.top())
            if center is not None
            else None
        )
        if self.geometry() != rect:
            self.setGeometry(rect)
        self.update()
        if not self.isVisible():
            self.show()

    def clear_ring(self) -> None:
        self._points = []
        self._center = None
        self.hide()

    def paintEvent(self, event) -> None:
        if not self._points:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)

        if self._center is not None and len(self._points) > 1:
            pen = QPen(AMBER_DIM, 2, Qt.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawPolygon(QPolygonF([QPointF(point) for point in self._points]))

        if self._center is not None:
            painter.setPen(QPen(AMBER, 2))
            painter.drawLine(self._center.x() - 14, self._center.y(), self._center.x() + 14, self._center.y())
            painter.drawLine(self._center.x(), self._center.y() - 14, self._center.x(), self._center.y() + 14)

        font = QFont()
        font.setPixelSize(11)
        font.setBold(True)
        painter.setFont(font)
        for index, point in enumerate(self._points, start=1):
            painter.setPen(QPen(QColor(255, 255, 255, 235), 2))
            painter.setBrush(AMBER)
            painter.drawEllipse(point, 10, 10)
            painter.setPen(INK)
            rect = QRect(point.x() - 10, point.y() - 10, 20, 20)
            painter.drawText(rect, int(Qt.AlignCenter), str(index))
