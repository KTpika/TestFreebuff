"""Circle placement builder: one click for the centre, live preview of the ring."""

from __future__ import annotations

from PySide6.QtCore import QRect
from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QVBoxLayout,
)

from .. import window
from ..aa.farm import Placement
from ..aa.placement import PATTERNS, cycle_slots
from .capture import PointPicker
from .preview import RingPreview


class CircleDialog(QDialog):
    def __init__(self, parent=None, defaults: dict | None = None):
        super().__init__(parent)
        defaults = defaults or {}
        self.setWindowTitle("Circle placement")
        self.setMinimumWidth(430)

        saved_center = defaults.get("center")
        # The window middle is the sensible starting circle, so most rings need no picking at all.
        self.center: list[float] | None = list(saved_center) if saved_center else [0.5, 0.5]
        self.center_label = QLabel(
            f"{self.center[0]:.1%}, {self.center[1]:.1%}" if saved_center else "window middle (default)"
        )

        pick = QPushButton("Pick centre…")
        pick.setToolTip("Click the middle of the circle on the map.")
        pick.clicked.connect(self._pick)

        pick_edge = QPushButton("Pick edge…")
        pick_edge.setToolTip(
            "Click any point on the circle's edge and the radius is measured for you — "
            "no need to guess a percentage."
        )
        pick_edge.clicked.connect(self._pick_edge)

        center_row = QHBoxLayout()
        center_row.addWidget(self.center_label, 1)
        center_row.addWidget(pick)
        center_row.addWidget(pick_edge)

        self.slot = QSpinBox()
        self.slot.setRange(1, 6)
        self.slot.setValue(int(defaults.get("slot", 1)))

        self.upgrades = QSpinBox()
        self.upgrades.setRange(0, 20)
        self.upgrades.setValue(int(defaults.get("upgrades", 2)))

        self.count = QSpinBox()
        self.count.setRange(1, 30)
        self.count.setValue(int(defaults.get("count", 8)))

        self.cycle = QCheckBox("Give each position the next unit slot (1 → 6)")
        self.cycle.setChecked(bool(defaults.get("cycle", True)))
        self.cycle.setToolTip(
            "On: a six-position ring places unit 1, then 2, … then 6 — one circle for your "
            "whole team. Off: every position places the same unit slot."
        )

        presets = QHBoxLayout()
        presets.addWidget(QLabel("Quick count"))
        for value in (4, 6, 8, 12):
            button = QPushButton(str(value))
            button.setFixedWidth(38)
            button.clicked.connect(lambda _checked=False, n=value: self.count.setValue(n))
            presets.addWidget(button)
        presets.addStretch(1)

        self.radius = QSpinBox()
        self.radius.setRange(2, 60)
        self.radius.setValue(int(defaults.get("radius", 18)))
        self.radius.setSuffix(" % of width")
        self.radius.setToolTip("How wide the circle is, as a share of the Roblox window's width.")

        self.radius_px_label = QLabel("")
        self.radius_px_label.setStyleSheet("color: #8a8377;")

        self.pattern = QComboBox()
        self.pattern.addItems(list(PATTERNS.keys()))
        if defaults.get("pattern"):
            index = self.pattern.findText(str(defaults["pattern"]))
            if index >= 0:
                self.pattern.setCurrentIndex(index)

        form = QFormLayout()
        form.addRow("Unit slot", self.slot)
        form.addRow("", self.cycle)
        form.addRow("Upgrades", self.upgrades)
        form.addRow("Positions", self.count)
        form.addRow("", presets)
        form.addRow("Pattern", self.pattern)
        form.addRow("Radius", self.radius)
        form.addRow("", self.radius_px_label)
        form.addRow("Centre", center_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)

        self.preview = RingPreview()
        self.count.valueChanged.connect(self._update_preview)
        self.radius.valueChanged.connect(self._update_preview)
        self.pattern.currentIndexChanged.connect(self._update_preview)
        self.slot.valueChanged.connect(self._update_preview)
        self.finished.connect(lambda _result: self.preview.close())

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        hint = QLabel(
            "The circle starts in the middle of the Roblox window — change it with “Pick centre…” "
            "and size it with “Pick edge…”. The numbered dots show where units land, and with "
            "slot cycling on they land as units 1→6."
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addWidget(buttons)

    # ------------------------------------------------------------------ picking

    def _pick(self) -> None:
        self.preview.clear_ring()
        self.hide()
        picker = PointPicker(self.parent(), "Click the centre of the circle")
        picker.picked.connect(self._picked)
        picker.show()

    def _picked(self, point) -> None:
        self.show()
        self.raise_()
        self.activateWindow()
        if point is None:
            self._update_preview()
            return
        found = window.find_game_window()
        if found is None or not found.rect.contains(point.x(), point.y()):
            QMessageBox.warning(self, "Outside the game", "Pick a point inside the Roblox window.")
            self._update_preview()
            return
        fx, fy = found.rect.to_relative(point.x(), point.y())
        self.center = [fx, fy]
        self.center_label.setText(f"{fx:.1%}, {fy:.1%}")
        self._update_preview()

    def _pick_edge(self) -> None:
        if self.center is None:
            QMessageBox.warning(self, "No centre", "Pick the circle's centre first.")
            return
        self.preview.clear_ring()
        self.hide()
        picker = PointPicker(self.parent(), "Click a point on the circle's edge")
        picker.picked.connect(self._picked_edge)
        picker.show()

    def _picked_edge(self, point) -> None:
        self.show()
        self.raise_()
        self.activateWindow()
        if point is None:
            self._update_preview()
            return
        found = window.find_game_window()
        if found is None or not found.rect.contains(point.x(), point.y()):
            QMessageBox.warning(self, "Outside the game", "Pick a point inside the Roblox window.")
            self._update_preview()
            return

        center_x = self.center[0] * found.rect.width
        center_y = self.center[1] * found.rect.height
        local_x, local_y = found.rect.to_relative(point.x(), point.y())
        edge_x = local_x * found.rect.width
        edge_y = local_y * found.rect.height
        distance = ((edge_x - center_x) ** 2 + (edge_y - center_y) ** 2) ** 0.5
        percent = round(distance / max(1, found.rect.width) * 100.0)
        self.radius.setValue(max(self.radius.minimum(), min(self.radius.maximum(), percent)))
        self._update_preview()

    # ------------------------------------------------------------------ preview

    def _game_rect(self):
        found = window.find_game_window()
        return found.rect if found is not None else None

    def _points(self, rect) -> tuple[list[tuple[float, float]], tuple[float, float]]:
        center_x = self.center[0] * rect.width
        center_y = self.center[1] * rect.height
        radius = rect.width * self.radius.value() / 100.0

        generator = PATTERNS.get(self.pattern.currentText())
        if generator is None:
            return [], (center_x, center_y)

        points = [(rect.left + x, rect.top + y) for x, y in generator(
            center_x, center_y, self.count.value(), radius, radius
        )]
        return points, (rect.left + center_x, rect.top + center_y)

    def _update_preview(self, *_args) -> None:
        rect = self._game_rect()
        if self.center is None or rect is None:
            self.preview.clear_ring()
            self.radius_px_label.setText("Pick a centre to preview the circle.")
            return

        points, center = self._points(rect)
        self.radius_px_label.setText(
            f"≈ {rect.width * self.radius.value() / 100.0:.0f} px on a {rect.width}×{rect.height} window"
        )
        if self.isVisible():
            frame = QRect(rect.left, rect.top, rect.width, rect.height)
            self.preview.set_ring(points, center, frame)

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self._update_preview()

    def hideEvent(self, event) -> None:
        self.preview.clear_ring()
        super().hideEvent(event)

    # ------------------------------------------------------------------- result

    def _accept(self) -> None:
        if self.center is None:
            QMessageBox.warning(self, "No centre", "Pick the circle's centre first.")
            return
        self.accept()

    def values(self) -> dict:
        """Remembered so the next circle starts where this one left off."""
        return {
            "center": list(self.center) if self.center else None,
            "slot": self.slot.value(),
            "upgrades": self.upgrades.value(),
            "count": self.count.value(),
            "radius": self.radius.value(),
            "pattern": self.pattern.currentText(),
            "cycle": self.cycle.isChecked(),
        }

    def placements(self) -> list[Placement]:
        if self.center is None:
            return []

        found = window.find_game_window()
        rect = found.rect if found is not None else None
        width = rect.width if rect else 1280
        height = rect.height if rect else 800

        center_x = self.center[0] * width
        center_y = self.center[1] * height
        radius = width * self.radius.value() / 100.0

        generator = PATTERNS.get(self.pattern.currentText())
        if generator is None:
            return []

        points = generator(center_x, center_y, self.count.value(), radius, radius)
        if self.cycle.isChecked():
            slots = cycle_slots(len(points), self.slot.value())
        else:
            slots = [self.slot.value()] * len(points)

        return [
            Placement(
                slot=slots[index] if index < len(slots) else self.slot.value(),
                x=min(1.0, max(0.0, x / width)),
                y=min(1.0, max(0.0, y / height)),
                upgrades=self.upgrades.value(),
            )
            for index, (x, y) in enumerate(points)
        ]
