#!/usr/bin/env bash
# Launch CapyMacro, creating the virtual environment on first run and refreshing
# dependencies whenever requirements.txt changes (new macOS frameworks included).
set -euo pipefail

cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "python3 was not found. Install Python 3.10 or newer from python.org first." >&2
  exit 1
fi

STAMP=".venv/.requirements.sha256"
WANT=$(shasum -a 256 requirements.txt | awk '{print $1}')

if [ ! -d .venv ]; then
  echo "First run: creating .venv (this takes a minute)…"
  python3 -m venv .venv
  ./.venv/bin/python -m pip install --quiet --upgrade pip
fi

HAVE=""
if [ -f "$STAMP" ]; then
  HAVE=$(cat "$STAMP")
fi

if [ "$HAVE" != "$WANT" ]; then
  echo "Installing/updating dependencies from requirements.txt…"
  ./.venv/bin/python -m pip install --quiet -r requirements.txt
  echo "$WANT" > "$STAMP"
fi

exec ./.venv/bin/python -m capymacro "$@"
