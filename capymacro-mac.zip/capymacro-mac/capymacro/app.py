"""Application bootstrap, with a crash log so a native crash is diagnosable."""

from __future__ import annotations

import faulthandler
import sys
import traceback
from datetime import datetime

from . import DATA


def _crash_path():
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        return DATA / "crash.log"
    except Exception:
        return None


def install_crash_log() -> None:
    """Keep a traceback even when Python dies in native code (SIGTRAP/abort)."""
    path = _crash_path()
    if path is None:
        return
    try:
        handle = open(path, "a", encoding="utf-8", buffering=1)
    except Exception:
        return
    handle.write(f"\n=== CapyMacro start {datetime.now():%Y-%m-%d %H:%M:%S} ===\n")
    faulthandler.enable(handle, all_threads=True)

    def _hook(exc_type, exc, tb):
        try:
            handle.write("".join(traceback.format_exception(exc_type, exc, tb)))
        except Exception:
            pass
        sys.__excepthook__(exc_type, exc, tb)

    sys.excepthook = _hook


def main() -> int:
    from PySide6.QtWidgets import QApplication

    from .ui.main_window import MainWindow

    install_crash_log()

    app = QApplication(sys.argv)
    app.setApplicationName("CapyMacro")
    app.setApplicationDisplayName("CapyMacro")
    app.setOrganizationName("CapyMacro")

    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
