"""CapyMacro for Anime Adventures on macOS."""

from __future__ import annotations

from pathlib import Path

__version__ = "0.1.0"

PACKAGE_DIR = Path(__file__).resolve().parent
ROOT = PACKAGE_DIR.parent
TEMPLATES = ROOT / "templates"
CONFIGS = ROOT / "configs"
DATA = ROOT / "data"

GAME = "Roblox"
GAME_HINTS = ("roblox",)


def ensure_dirs() -> None:
    for path in (TEMPLATES, CONFIGS, DATA):
        path.mkdir(parents=True, exist_ok=True)
