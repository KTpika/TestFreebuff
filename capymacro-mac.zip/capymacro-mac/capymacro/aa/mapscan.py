"""Work out which map the game is on from the text on screen.

The shipped map configs carry a display name, and Anime Adventures prints the
stage name on the stage-select screen and while a stage loads. One OCR pass is
therefore enough to pick the matching config, instead of scrolling through 58
entries in the map list.
"""

from __future__ import annotations

import difflib
import re
from dataclasses import dataclass

from . import configs as map_configs

# Below this the line is treated as "some text", not as a map name.
MATCH_THRESHOLD = 0.8
# A map that exists in both modes is slightly preferred in the selected mode.
OTHER_MODE_PENALTY = 0.9


@dataclass(frozen=True)
class MapMatch:
    config: map_configs.MapConfig
    text: str
    score: float


def normalise(text: str) -> str:
    """Lower-case letters and digits only, so spacing and punctuation do not matter."""
    return re.sub(r"[^a-z0-9]", "", (text or "").lower())


def _tokens(text: str) -> set[str]:
    return set(re.findall(r"[a-z0-9]+", (text or "").lower()))


def score(text: str, name: str) -> float:
    """How strongly one line of screen text names this map, from 0 to 1."""
    line, target = normalise(text), normalise(name)
    if len(line) < 4 or len(target) < 4:
        return 0.0
    if line == target:
        return 1.0

    shorter, longer = (line, target) if len(line) <= len(target) else (target, line)
    if shorter in longer:
        share = len(shorter) / len(longer)
        if share >= 0.5:
            # "ruined city act 1" contains "ruined city".
            return 0.8 + 0.15 * share

    # Every word of the map name appearing on the line is a strong signal;
    # otherwise the letters are compared, but only for names of similar length
    # so "Rain Village" is not mistaken for "Sand Village".
    line_tokens, name_tokens = _tokens(text), _tokens(name)
    covered = bool(name_tokens) and name_tokens <= line_tokens
    close_length = len(line) >= 8 and abs(len(line) - len(target)) <= 2
    if not (covered or close_length):
        return 0.0
    ratio = difflib.SequenceMatcher(None, line, target).ratio()
    floor = 0.8 if covered else 0.86
    if ratio >= floor:
        return 0.8 + 0.15 * (ratio - floor) / (1.0 - floor)
    return 0.0


def find_map(lines, mode: str | None = None, maps=None) -> MapMatch | None:
    """Best map config named by any of ``lines``.

    Every shipped config is considered, so a Summer map can still be recognised
    while the app is set to Infinite; a map that exists in the selected mode wins
    a tie against the same name in the other mode.
    """
    candidates = list(maps) if maps is not None else map_configs.load_maps()
    best: MapMatch | None = None

    for line in lines or ():
        for entry in candidates:
            value = max(
                score(line, entry.map_name),
                score(line, entry.display_name) if entry.display_name else 0.0,
            )
            if value <= 0.0:
                continue
            if mode and entry.mode.lower() != mode.lower():
                value *= OTHER_MODE_PENALTY
            if best is None or value > best.score:
                best = MapMatch(entry, line, value)

    if best is None or best.score < MATCH_THRESHOLD:
        return None
    return best


def read_map(view, mode: str | None = None, fast: bool = False) -> MapMatch | None:
    """Screenshot the game window and name the map shown on it."""
    from .. import vision

    if not vision.available():
        return None
    frame = view.frame()
    if frame is None:
        return None
    return find_map(vision.read_text(frame, fast=fast), mode=mode)
