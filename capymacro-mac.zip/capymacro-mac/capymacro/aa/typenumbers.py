"""number typing 

CapyMacro will need to type the numbers when it sees it
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path

from .. import vision

KEYWORDS = (
"Submit"
"Cancel"
"Please"
"Enter"
"this to enter"
)



_NOT_WORD = re.compile(r"[^a-z0-9]+")


def _compact(text: str) -> str:
    return _NOT_WORD.sub("", text.lower())


def matches(text: str) -> str | None:
    """Return the keyword that matched, if any (pure; easy to test)."""
    compact = _compact(text)
    if not compact:
        return None
    for keyword in KEYWORDS:
        if keyword in compact:
            return keyword
    return None


def detect(frame) -> str | None:
    """Read the screen quickly and look for a a number typing prompt."""
    if frame is None or not vision.available():
        return None
    return matches(" ".join(vision.read_text(frame, fast=True, max_width=1280)))


#type in the number shown on screen located in the box with "?"
#then click submit