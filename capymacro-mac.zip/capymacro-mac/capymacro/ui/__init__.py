"""UI package for CapyMacro."""
