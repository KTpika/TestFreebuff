#!/usr/bin/env bash
# Double-click this file in Finder to start CapyMacro.
cd "$(dirname "$0")" || exit 1
exec ./run.sh
