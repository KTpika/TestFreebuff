"""Global hotkeys through AppKit's event monitor.

pynput's keyboard listener asked Text Services Manager which character a key
produced, on its own background thread. macOS 26 traps that with
``dispatch_assert_queue_fail`` → SIGTRAP, which is what crashed CapyMacro. The
AppKit global monitor delivers the event on the main thread with its characters
already resolved, so nothing asks the input-source stack from a worker thread.
It needs Accessibility only; Input Monitoring is no longer required.
"""

from __future__ import annotations

from PySide6.QtCore import QObject, Signal

try:  # QtGui needs the platform plugins; the key parser still works without them
    from PySide6.QtGui import QKeySequence
except Exception:  # pragma: no cover - headless development machines
    QKeySequence = None

try:  # macOS global key monitor
    from AppKit import NSEvent, NSEventMaskKeyDown
except Exception:  # pragma: no cover - non-macOS development machines
    NSEvent = None
    NSEventMaskKeyDown = None

from . import permissions

# Characters AppKit reports for keys that have no printable character.
_SPECIAL_CHARS = {
    "\x1b": "esc",
    "\r": "return",
    "\t": "tab",
    "\x7f": "backspace",
    " ": "space",
    "\uf700": "up",
    "\uf701": "down",
    "\uf702": "left",
    "\uf703": "right",
    "\uf729": "home",
    "\uf72b": "end",
    "\uf72c": "pageup",
    "\uf72d": "pagedown",
    "\uf728": "delete",
}
for _index in range(12):
    _SPECIAL_CHARS[chr(0xF704 + _index)] = f"f{_index + 1}"


def normalise_key(spec: str) -> str:
    """A QKeySequence string reduced to the key itself, e.g. ``]`` or ``F5``."""
    text = (spec or "").strip()
    if not text:
        return ""
    if QKeySequence is not None:
        sequence = QKeySequence(text)
        if not sequence.isEmpty():
            text = sequence.toString(QKeySequence.PortableText)
    return text.strip()


def key_name(spec: str) -> str:
    """The comparable name of a key: ``]``, ``w``, ``esc``, ``f5``."""
    text = normalise_key(spec)
    if not text:
        return ""
    lowered = text.lower()
    if len(text) == 1:
        return lowered
    if lowered in ("escape", "return", "enter", "space", "tab", "backspace"):
        return "esc" if lowered == "escape" else ("return" if lowered == "enter" else lowered)
    return lowered


def event_key(event) -> str:
    """The key an AppKit event carries, named like ``key_name``."""
    try:
        chars = event.charactersIgnoringModifiers() or ""
    except Exception:
        return ""
    if not chars:
        return ""
    first = chars[0]
    if first in _SPECIAL_CHARS:
        return _SPECIAL_CHARS[first]
    return first.lower()


class Hotkeys(QObject):
    """One configurable start key plus Esc, watched by a main-thread monitor."""

    run_toggled = Signal()
    stop_pressed = Signal()

    def __init__(self, parent=None, start_key: str = "]"):
        super().__init__(parent)
        self._monitor = None
        self._start_key = normalise_key(start_key) or "]"

    @staticmethod
    def available() -> bool:
        return NSEvent is not None

    @staticmethod
    def globally_allowed() -> bool:
        """True when macOS lets a global key monitor run (Accessibility)."""
        if NSEvent is None:
            return False
        return permissions.accessibility_granted() is not False

    def set_start_key(self, spec: str) -> None:
        spec = normalise_key(spec) or "]"
        if spec == self._start_key:
            return
        self._start_key = spec
        if self._monitor is not None:
            self.stop_global()
            self.start_global()

    @property
    def start_key(self) -> str:
        return self._start_key

    def start_global(self) -> bool:
        """Watch for the start key and Esc. Must be called from the main thread."""
        if self._monitor is not None:
            return True
        if not self.globally_allowed():
            return False
        if not key_name(self._start_key):
            return False

        try:
            self._monitor = NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(
                NSEventMaskKeyDown, self._handle
            )
        except Exception:
            self._monitor = None
            return False
        return self._monitor is not None

    def stop_global(self) -> None:
        if self._monitor is None:
            return
        monitor, self._monitor = self._monitor, None
        try:
            NSEvent.removeMonitor_(monitor)
        except Exception:
            pass

    def start_escape(self) -> None:
        """Esc is watched by the same monitor, so nothing to add."""

    def stop_escape(self) -> None:
        """Esc is watched by the same monitor, so nothing to remove."""

    def stop(self) -> None:
        self.stop_global()

    def _handle(self, event) -> None:
        name = event_key(event)
        if not name:
            return
        if name == "esc":
            self._emit(self.stop_pressed)
            return
        if name == key_name(self._start_key):
            self._emit(self.run_toggled)

    @staticmethod
    def _emit(signal: Signal) -> None:
        try:
            signal.emit()
        except RuntimeError:
            pass
