"""The CapyMacro window for Anime Adventures."""

from __future__ import annotations

import sys
import time
from datetime import datetime

from PySide6.QtCore import Qt, QTimer, QUrl, Signal
from PySide6.QtGui import QAction, QDesktopServices, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QDoubleSpinBox,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QKeySequenceEdit,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QStackedWidget,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .. import CONFIGS, DATA, bundle, ensure_dirs, permissions, screen, vision, window
from ..aa import configs as map_configs, mapscan
from ..aa.assets import GameView
from ..aa.farm import MODES, FarmConfig, FarmEngine, Placement
from ..aa.session import load_json, post_webhook, save_json, session_embed, Session
from ..hotkeys import Hotkeys
from .capture import PointPicker
from .circle_dialog import CircleDialog
from .game_panel import GamePanel, GameWindow
from .unit_card import UnitCard

CONFIG_PATH = DATA / "farm.json"
AUTO_MAP = "Auto — detect on screen"


class PlacementDialog(QDialog):
    """Slot, upgrades and an on-screen position for one unit."""

    def __init__(
        self,
        parent=None,
        placement: Placement | None = None,
        point=None,
    ):
        super().__init__(parent)
        if placement is None and point is not None:
            placement = Placement(x=float(point[0]), y=float(point[1]))
        self.setWindowTitle("Unit placement")
        self.setMinimumWidth(360)

        self.slot = QSpinBox()
        self.slot.setRange(1, 6)
        self.slot.setValue(placement.slot if placement else 1)

        self.upgrades = QSpinBox()
        self.upgrades.setRange(0, 20)
        self.upgrades.setValue(placement.upgrades if placement else 2)

        self.point: list[float] | None = [placement.x, placement.y] if placement else None
        self.position_label = QLabel(
            f"{placement.x:.1%}, {placement.y:.1%}" if placement else "not picked yet"
        )

        pick = QPushButton("Pick on screen…")
        pick.clicked.connect(self._pick)

        position_row = QHBoxLayout()
        position_row.addWidget(self.position_label, 1)
        position_row.addWidget(pick)

        form = QFormLayout()
        form.addRow("Unit slot", self.slot)
        form.addRow("Upgrades", self.upgrades)
        form.addRow("Position", position_row)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def _pick(self) -> None:
        self.hide()
        picker = PointPicker(self.parent(), "Click where this unit should go")
        picker.picked.connect(self._picked)
        picker.show()

    def _picked(self, point) -> None:
        self.show()
        self.raise_()
        self.activateWindow()
        if point is None:
            return
        found = window.find_game_window()
        if found is None or not found.rect.contains(point.x(), point.y()):
            QMessageBox.warning(self, "Outside the game", "Pick a point inside the Roblox window.")
            return
        fx, fy = found.rect.to_relative(point.x(), point.y())
        self.point = [fx, fy]
        self.position_label.setText(f"{fx:.1%}, {fy:.1%}")

    def _accept(self) -> None:
        if self.point is None:
            QMessageBox.warning(self, "No position", "Pick the unit's position first.")
            return
        self.accept()

    def placement(self) -> Placement:
        return Placement(
            slot=self.slot.value(),
            x=self.point[0] if self.point else 0.5,
            y=self.point[1] if self.point else 0.5,
            upgrades=self.upgrades.value(),
        )


class MainWindow(QMainWindow):
    logged = Signal(str)
    stats_updated = Signal(dict)
    run_finished = Signal(bool, str)

    def __init__(self):
        super().__init__()
        ensure_dirs()

        self.config = FarmConfig()
        loaded = load_json(CONFIG_PATH)
        if loaded:
            self.config = FarmConfig.from_dict(loaded)

        self._engine: FarmEngine | None = None
        self._last_stats: dict = {}
        self._session_started = time.time()
        self._circle_defaults: dict = {}
        self._panel_action: str | None = None
        self._game_window: GameWindow | None = None
        self._shortcuts: list[QShortcut] = []

        self._build_ui()
        self._build_menu()

        self.logged.connect(self._log)
        self.stats_updated.connect(self._on_stats)
        self.run_finished.connect(self._on_finished)

        self._hotkeys = Hotkeys(self, start_key=self.config.start_hotkey)
        self._hotkeys.run_toggled.connect(self._toggle_run)
        self._hotkeys.stop_pressed.connect(self._stop_run)
        if self._hotkeys.start_global():
            self._log(f"Global start key: {self._hotkeys.start_key} · Esc stops a run.")
        else:
            self._log(
                "Global hotkeys need Accessibility — the buttons and the in-app "
                "shortcut still work without it."
            )
        self._install_shortcuts()

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._refresh_window)
        self._timer.start(2000)

        self._apply_config()
        self._refresh_window()
        self._log(
            f"Ready. Pick a mode, set your start clicks and placements, then press Start "
            f"({self.config.start_hotkey})."
        )
        if not self._hotkeys.available():
            self._log("Global hotkeys unavailable — use the buttons or the in-app shortcut.")

    # --------------------------------------------------------------------- UI

    def _build_ui(self) -> None:
        self.setWindowTitle("CapyMacro — Anime Adventures")
        self.resize(980, 900)

        central = QWidget(self)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(16, 14, 16, 12)
        layout.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("CapyMacro")
        title.setStyleSheet("font-size: 20px; font-weight: 600;")
        header.addWidget(title)
        self.record_label = QLabel()
        self.record_label.setToolTip("Wins and losses across all sessions, and the win rate.")
        header.addSpacing(12)
        header.addWidget(self.record_label)
        self.window_label = QLabel("Looking for Roblox…")
        header.addSpacing(14)
        header.addWidget(self.window_label)
        header.addStretch(1)
        check = QPushButton("Check window")
        check.clicked.connect(self._refresh_window)
        header.addWidget(check)

        screen_check = QPushButton("Screen check")
        screen_check.setToolTip(
            "Log what the macro can see: window size, whether the screenshot worked and "
            "the text Apple Vision reads on screen. Use this when Play or a map is not recognised."
        )
        screen_check.clicked.connect(self._screen_check)
        header.addWidget(screen_check)

        permissions_button = QPushButton("Permissions")
        permissions_button.setToolTip(
            "Show and request macOS Screen Recording, Accessibility and Input Monitoring."
        )
        permissions_button.clicked.connect(self._show_permissions)
        header.addWidget(permissions_button)
        layout.addLayout(header)

        # ---- Mode and run controls
        farm_box = QGroupBox("Farm")
        farm_layout = QHBoxLayout(farm_box)
        farm_layout.setSpacing(8)

        farm_layout.addWidget(QLabel("Mode"))
        self.mode_combo = QComboBox()
        self.mode_combo.addItems(MODES)
        self.mode_combo.currentIndexChanged.connect(self._on_mode_changed)
        farm_layout.addWidget(self.mode_combo)

        farm_layout.addWidget(QLabel("Map"))
        self.map_combo = QComboBox()
        self.map_combo.setMinimumWidth(240)
        self.map_combo.setToolTip(
            "Auto reads the stage name from the game screen and picks that map config, "
            "so you do not have to find the map in the list."
        )
        farm_layout.addWidget(self.map_combo)

        self.detect_button = QPushButton("Detect map")
        self.detect_button.setToolTip(
            "Read the map name that is on screen right now and select it in the list."
        )
        self.detect_button.clicked.connect(self._detect_map_now)
        farm_layout.addWidget(self.detect_button)

        farm_layout.addWidget(QLabel("Runs"))
        self.runs_spin = QSpinBox()
        self.runs_spin.setRange(0, 9999)
        self.runs_spin.setSpecialValueText("∞")
        farm_layout.addWidget(self.runs_spin)

        self.dry_run_check = QCheckBox("Dry run")
        farm_layout.addWidget(self.dry_run_check)

        self.captcha_check = QCheckBox("Captcha guard")
        self.captcha_check.setToolTip(
            "Check the screen about once a second (and before every click). If Roblox shows a "
            "human-verification prompt, input pauses and you get a notification + sound; the "
            "macro resumes after two clear screens. It never tries to solve the prompt."
        )
        farm_layout.addWidget(self.captcha_check)

        farm_layout.addStretch(1)

        self.start_button = QPushButton(f"Start  ({self.config.start_hotkey})")
        self.start_button.clicked.connect(self._start_run)
        farm_layout.addWidget(self.start_button)

        self.stop_button = QPushButton("Stop  (Esc)")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self._stop_run)
        farm_layout.addWidget(self.stop_button)

        tabs = QTabWidget()
        farm_page = QWidget()
        farm_page_layout = QVBoxLayout(farm_page)
        farm_page_layout.setContentsMargins(0, 0, 0, 0)
        farm_page_layout.setSpacing(10)
        farm_page_layout.addWidget(farm_box)

        # ---- Mode-specific settings
        self.mode_stack = QStackedWidget()
        self.mode_stack.addWidget(self._build_infinite_page())
        self.mode_stack.addWidget(self._build_summer_page())
        self.mode_stack.addWidget(self._build_dungeon_page())
        farm_page_layout.addWidget(self.mode_stack)

        # ---- Setup points
        setup_box = QGroupBox("Setup")
        setup_layout = QVBoxLayout(setup_box)
        setup_layout.setSpacing(6)

        start_row = QHBoxLayout()
        start_row.addWidget(QLabel("Start clicks (mode → map → play):"))
        self.start_clicks_label = QLabel("0")
        start_row.addWidget(self.start_clicks_label)
        add_start = QPushButton("Add click…")
        add_start.clicked.connect(self._add_start_click)
        start_row.addWidget(add_start)
        clear_start = QPushButton("Clear")
        clear_start.clicked.connect(self._clear_start_clicks)
        start_row.addWidget(clear_start)
        start_row.addStretch(1)
        setup_layout.addLayout(start_row)

        self.vote_row_widget = QWidget()
        vote_row = QHBoxLayout(self.vote_row_widget)
        vote_row.setContentsMargins(0, 0, 0, 0)
        vote_row.addWidget(QLabel("Vote clicks (open vote → pick lose):"))
        self.vote_clicks_label = QLabel("0")
        vote_row.addWidget(self.vote_clicks_label)
        add_vote = QPushButton("Add click…")
        add_vote.clicked.connect(self._add_vote_click)
        vote_row.addWidget(add_vote)
        clear_vote = QPushButton("Clear")
        clear_vote.clicked.connect(self._clear_vote_clicks)
        vote_row.addWidget(clear_vote)
        vote_row.addStretch(1)
        setup_layout.addWidget(self.vote_row_widget)

        farm_page_layout.addWidget(setup_box)

        # ---- Placements
        placement_box = QGroupBox("Unit placements")
        placement_layout = QVBoxLayout(placement_box)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Slot", "Position", "Upgrades"])
        self.table.verticalHeader().setVisible(False)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setMinimumHeight(110)
        table_header = self.table.horizontalHeader()
        table_header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        table_header.setSectionResizeMode(1, QHeaderView.Stretch)
        table_header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        self.table.doubleClicked.connect(lambda _index: self._edit_placement())
        placement_layout.addWidget(self.table)

        placement_buttons = QHBoxLayout()
        add_placement = QPushButton("Add placement…")
        add_placement.clicked.connect(self._add_placement)
        placement_buttons.addWidget(add_placement)
        circle = QPushButton("Circle placement…")
        circle.clicked.connect(self._add_circle)
        placement_buttons.addWidget(circle)
        edit_placement = QPushButton("Edit…")
        edit_placement.clicked.connect(self._edit_placement)
        placement_buttons.addWidget(edit_placement)
        remove_placement = QPushButton("Remove")
        remove_placement.clicked.connect(self._remove_placement)
        placement_buttons.addWidget(remove_placement)
        clear_placements = QPushButton("Clear all")
        clear_placements.clicked.connect(self._clear_placements)
        placement_buttons.addWidget(clear_placements)
        placement_buttons.addStretch(1)
        placement_layout.addLayout(placement_buttons)

        farm_page_layout.addWidget(placement_box)

        # ---- Connection
        connection_box = QGroupBox("Connection")
        connection_layout = QFormLayout(connection_box)
        self.hotkey_edit = QKeySequenceEdit()
        self.hotkey_edit.setMaximumWidth(130)
        self.hotkey_edit.setToolTip("Key that starts and stops a run. Default: ] — Esc always stops.")
        self.hotkey_edit.editingFinished.connect(self._hotkey_changed)
        connection_layout.addRow("Start hotkey", self.hotkey_edit)

        self.ability_edit = QKeySequenceEdit()
        self.ability_edit.setMaximumWidth(130)
        self.ability_edit.setToolTip(
            "Key pressed after placing a unit whose Auto ability box is ticked. Leave empty to skip abilities."
        )
        connection_layout.addRow("Ability key", self.ability_edit)

        self.private_server_edit = QLineEdit()
        self.private_server_edit.setPlaceholderText("https://www.roblox.com/share?code=… (private server link)")
        connection_layout.addRow("Private server", self.private_server_edit)
        self.webhook_edit = QLineEdit()
        self.webhook_edit.setPlaceholderText("https://discord.com/api/webhooks/… (optional)")
        connection_layout.addRow("Discord webhook", self.webhook_edit)

        self.lobby_check = QCheckBox("Return to the lobby after each match")
        self.lobby_check.setToolTip(
            "After a win or a loss, click the Lobby button, then press Play and Matchmaking "
            "for the next run."
        )
        connection_layout.addRow("", self.lobby_check)

        self.auto_reconnect_check = QCheckBox("Rejoin automatically after a disconnect")
        self.auto_reconnect_check.setToolTip(
            "Watch the screen for Roblox's disconnect dialog, click Reconnect, reopen "
            "your private server link if needed and carry on with the next run."
        )
        connection_layout.addRow("", self.auto_reconnect_check)

        self.auto_play_check = QCheckBox("Press the Play button automatically")
        self.auto_play_check.setToolTip(
            "After the start clicks, find Roblox's Play button with OCR and press it, so "
            "the run begins without another recorded click. Also re-enters the game after "
            "a reconnect."
        )
        connection_layout.addRow("", self.auto_play_check)
        farm_page_layout.addWidget(connection_box)
        farm_page_layout.addStretch(1)

        tabs.addTab(farm_page, "Farm")
        tabs.addTab(self._build_units_tab(), "Units")
        layout.addWidget(tabs, 1)

        # ---- Log and the live game view, side by side
        bottom = QHBoxLayout()
        bottom.setSpacing(10)

        log_box = QGroupBox("Log")
        log_layout = QVBoxLayout(log_box)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setMaximumBlockCount(3000)
        self.log_view.setMinimumHeight(170)
        log_layout.addWidget(self.log_view)
        bottom.addWidget(log_box, 1)

        live_box = QGroupBox("Roblox live view")
        live_layout = QVBoxLayout(live_box)
        self.game_panel = GamePanel()
        self.game_panel.clicked.connect(self._panel_click)
        live_layout.addWidget(self.game_panel, 1)

        panel_row = QHBoxLayout()
        for text, action in (
            ("Placement", "placement"),
            ("Start click", "start"),
            ("Vote click", "vote"),
        ):
            button = QPushButton(text)
            button.clicked.connect(lambda _checked=False, a=action: self._arm_panel(a))
            panel_row.addWidget(button)
        live_layout.addLayout(panel_row)

        self.panel_hint = QLabel("Pick an action, then click the game view.")
        self.panel_hint.setWordWrap(True)
        live_layout.addWidget(self.panel_hint)

        popout = QPushButton("Pop out view")
        popout.setToolTip("Show the live view in its own always-on-top window (e.g. on a second display).")
        popout.clicked.connect(self._toggle_game_window)
        live_layout.addWidget(popout)
        bottom.addWidget(live_box, 1)

        layout.addLayout(bottom, 1)

        self.setCentralWidget(central)
        self.statusBar().showMessage("Idle")

        self._populate_maps()

    def _build_infinite_page(self) -> QWidget:
        page = QGroupBox("Infinite gem farm")
        row = QHBoxLayout(page)
        row.addWidget(QLabel("Vote at wave"))
        self.wave_spin = QSpinBox()
        self.wave_spin.setRange(1, 100)
        row.addWidget(self.wave_spin)
        row.addWidget(QLabel("Give up after (minutes)"))
        self.vote_timeout_spin = QSpinBox()
        self.vote_timeout_spin.setRange(1, 120)
        row.addWidget(self.vote_timeout_spin)
        row.addStretch(1)
        return page

    def _build_units_tab(self) -> QWidget:
        page = QWidget()
        outer = QVBoxLayout(page)
        outer.setContentsMargins(0, 6, 0, 0)

        note = QLabel(
            "Units are placed in Placement priority order, then upgraded in Upgrade priority "
            "order. Placements 0 uses every recorded position for that unit; Upgrade limit "
            "only applies when Enable upgrade limit is ticked."
        )
        note.setWordWrap(True)
        outer.addWidget(note)

        grid = QGridLayout()
        grid.setSpacing(8)
        self.unit_cards: list[UnitCard] = []
        for index, settings in enumerate(self.config.units):
            card = UnitCard(settings)
            self.unit_cards.append(card)
            grid.addWidget(card, index // 3, index % 3)
        outer.addLayout(grid)
        outer.addStretch(1)
        return page

    def _build_summer_page(self) -> QWidget:
        page = QGroupBox("Summer event")
        column = QVBoxLayout(page)
        note = QLabel(
            "Record the Summer buttons — event tab, map, and the matchmaking or party toggle — "
            "as start clicks. The macro then plays each run and starts the next one."
        )
        note.setWordWrap(True)
        column.addWidget(note)

        self.matchmaking_check = QCheckBox("Click Matchmaking / Find Match automatically")
        self.matchmaking_check.setToolTip(
            "After Play, find the Summer queue panel with OCR and press Find Match "
            "(and any Matchmaking button in the lobby before Play)."
        )
        column.addWidget(self.matchmaking_check)

        walk_row = QHBoxLayout()
        walk_row.addWidget(QLabel("Walk forward after Play (seconds)"))
        self.walk_spin = QDoubleSpinBox()
        self.walk_spin.setRange(0.0, 20.0)
        self.walk_spin.setSingleStep(0.5)
        self.walk_spin.setDecimals(1)
        self.walk_spin.setSpecialValueText("off")
        self.walk_spin.setToolTip(
            "Holds W for this long after pressing Play, so the character steps into the "
            "matchmaking queue. 0 turns it off. This is a timed straight walk — CapyMacro "
            "does not pathfind."
        )
        walk_row.addWidget(self.walk_spin)
        walk_row.addStretch(1)
        column.addLayout(walk_row)

        row = QHBoxLayout()
        row.addWidget(QLabel("Give up after (minutes)"))
        self.summer_timeout_spin = QSpinBox()
        self.summer_timeout_spin.setRange(1, 180)
        row.addWidget(self.summer_timeout_spin)
        row.addStretch(1)
        column.addLayout(row)
        return page

    def _build_dungeon_page(self) -> QWidget:
        page = QGroupBox("Dungeon")
        form = QFormLayout(page)

        self.dungeon_rooms_edit = QLineEdit()
        self.dungeon_rooms_edit.setToolTip(
            "Room labels to click, in priority order (comma separated). The first one on "
            "screen is chosen, then that label is ignored for a few seconds so one click "
            "counts as one choice. Add room-* curse labels (room-shopping, room-health, "
            "room-regen, …) to target curse doors."
        )
        form.addRow("Room priority", self.dungeon_rooms_edit)

        self.dungeon_shrines_edit = QLineEdit()
        self.dungeon_shrines_edit.setToolTip(
            "Shrine icons to pick, in priority order. When none of them is on screen the "
            "macro uses the normal Next / Continue button to leave the shrine."
        )
        form.addRow("Shrine priority", self.dungeon_shrines_edit)

        self.dungeon_shop_edit = QLineEdit()
        self.dungeon_shop_edit.setToolTip(
            "Shop item icons to buy, in priority order. Buying stops at the per-shop limit."
        )
        form.addRow("Shop priority", self.dungeon_shop_edit)

        row = QHBoxLayout()
        self.shop_limit_spin = QSpinBox()
        self.shop_limit_spin.setRange(0, 20)
        row.addWidget(QLabel("Buys per shop"))
        row.addWidget(self.shop_limit_spin)

        self.chests_combo = QComboBox()
        self.chests_combo.addItems(["End", "Now"])
        self.chests_combo.setToolTip(
            "End saves reward chests for the end of the dungeon; Now opens each reward panel "
            "as it appears."
        )
        row.addWidget(QLabel("Chests"))
        row.addWidget(self.chests_combo)

        self.heart_stop_spin = QSpinBox()
        self.heart_stop_spin.setRange(0, 10)
        self.heart_stop_spin.setToolTip(
            "Pause clicking when the dungeon heart count drops to this value (0 turns it "
            "off). The count is read with OCR from the top of the HUD; if it cannot be "
            "read the log says so once and the option stays inactive."
        )
        row.addWidget(QLabel("Stop at hearts"))
        row.addWidget(self.heart_stop_spin)
        row.addStretch(1)
        form.addRow("", row)

        hint = QLabel(
            "Names are template files in templates/AA (e.g. chests-title, shop-title, "
            "shrine-title, boss-label, shrine-vitality, shop-stormbringer). "
            "Press Start on the dungeon entrance screen."
        )
        hint.setWordWrap(True)
        form.addRow("", hint)
        return page

    def _build_menu(self) -> None:
        file_menu = self.menuBar().addMenu("&File")
        save = QAction("Save config", self)
        save.setShortcut(QKeySequence.Save)
        save.triggered.connect(lambda _checked=False: self._save_config(verbose=True))
        file_menu.addAction(save)
        open_folder = QAction("Show configs folder", self)
        open_folder.triggered.connect(
            lambda _checked=False: QDesktopServices.openUrl(QUrl.fromLocalFile(str(CONFIGS)))
        )
        file_menu.addAction(open_folder)
        file_menu.addSeparator()
        quit_action = QAction("Quit", self)
        quit_action.setShortcut(QKeySequence.Quit)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

        help_menu = self.menuBar().addMenu("&Help")
        permissions = QAction("macOS permissions…", self)
        permissions.triggered.connect(lambda _checked=False: self._show_permissions())
        help_menu.addAction(permissions)
        about = QAction("About CapyMacro", self)
        about.triggered.connect(lambda _checked=False: self._show_about())
        help_menu.addAction(about)

    # ------------------------------------------------------------------- data

    def _populate_maps(self) -> None:
        mode = self.mode_combo.currentText() or self.config.mode
        self.map_combo.blockSignals(True)
        self.map_combo.clear()

        if mode == "Dungeon":
            self.map_combo.addItem("Dungeon entrance", None)
            self.map_combo.setEnabled(False)
            self.detect_button.setEnabled(False)
        else:
            self.map_combo.setEnabled(True)
            self.detect_button.setEnabled(True)
            self.map_combo.addItem(AUTO_MAP, "auto")
            self.map_combo.setItemData(
                0,
                "Read the stage name off the screen at the start of every run.",
                Qt.ToolTipRole,
            )
            self.map_combo.insertSeparator(self.map_combo.count())
            for entry in map_configs.load_maps(mode):
                self.map_combo.addItem(entry.label, entry)
            index = self.map_combo.findText(f"{mode} · {self.config.map_name}")
            if self.config.auto_map or index < 0:
                self.map_combo.setCurrentIndex(0)
            else:
                self.map_combo.setCurrentIndex(index)

        self.map_combo.blockSignals(False)

    def _apply_config(self) -> None:
        index = self.mode_combo.findText(self.config.mode)
        self.mode_combo.setCurrentIndex(index if index >= 0 else 0)
        self.mode_stack.setCurrentIndex(max(0, self.mode_combo.currentIndex()))

        self.runs_spin.setValue(self.config.runs)
        self.wave_spin.setValue(self.config.vote_wave)
        self.vote_timeout_spin.setValue(max(1, int(self.config.vote_timeout // 60)))
        self.summer_timeout_spin.setValue(max(1, int(self.config.result_timeout // 60)))
        self.dry_run_check.setChecked(self.config.dry_run)
        self.captcha_check.setChecked(self.config.captcha_guard)
        self.auto_play_check.setChecked(self.config.auto_play)
        self.auto_reconnect_check.setChecked(self.config.auto_reconnect)
        self.matchmaking_check.setChecked(self.config.auto_matchmaking)
        self.walk_spin.setValue(self.config.queue_walk_seconds)
        self.lobby_check.setChecked(self.config.return_to_lobby)
        self.ability_edit.setKeySequence(QKeySequence(self.config.ability_key))
        self._refresh_units()
        self._update_record()
        self.hotkey_edit.setKeySequence(QKeySequence(self.config.start_hotkey))
        self._hotkeys.set_start_key(self.config.start_hotkey)
        self._install_shortcuts()
        self.start_button.setText(f"Start  ({self.config.start_hotkey})")
        self.private_server_edit.setText(self.config.private_server)
        self.webhook_edit.setText(self.config.webhook)

        self.dungeon_rooms_edit.setText(", ".join(self.config.dungeon_rooms))
        self.dungeon_shrines_edit.setText(", ".join(self.config.dungeon_shrines))
        self.dungeon_shop_edit.setText(", ".join(self.config.dungeon_shop))
        self.shop_limit_spin.setValue(self.config.dungeon_shop_limit)
        self.chests_combo.setCurrentText(self.config.dungeon_chests)
        self.heart_stop_spin.setValue(self.config.dungeon_heart_stop)

        self._populate_maps()
        self._refresh_setup_labels()
        self._refresh_table()
        self._update_mode_visibility()

    def _sync_config(self) -> None:
        self.config.mode = self.mode_combo.currentText()
        entry = self.map_combo.currentData()
        if entry == "auto":
            self.config.auto_map = True
        elif entry is not None:
            self.config.auto_map = False
            self.config.map_name = entry.map_name
        elif self.config.mode == "Dungeon":
            self.config.auto_map = False
            self.config.map_name = "Dungeon"
        self.config.runs = self.runs_spin.value()
        self.config.vote_wave = self.wave_spin.value()
        self.config.vote_timeout = self.vote_timeout_spin.value() * 60.0
        if self.config.mode == "Summer":
            self.config.result_timeout = self.summer_timeout_spin.value() * 60.0
        self.config.dry_run = self.dry_run_check.isChecked()
        self.config.captcha_guard = self.captcha_check.isChecked()
        self.config.auto_play = self.auto_play_check.isChecked()
        self.config.auto_reconnect = self.auto_reconnect_check.isChecked()
        self.config.auto_matchmaking = self.matchmaking_check.isChecked()
        self.config.queue_walk_seconds = float(self.walk_spin.value())
        self.config.return_to_lobby = self.lobby_check.isChecked()
        self.config.ability_key = (
            self.ability_edit.keySequence().toString(QKeySequence.PortableText).strip()
        )
        self.config.units = [card.settings() for card in self.unit_cards]
        hotkey = self.hotkey_edit.keySequence().toString(QKeySequence.PortableText).strip()
        self.config.start_hotkey = hotkey or "]"
        self.config.private_server = self.private_server_edit.text().strip()
        self.config.webhook = self.webhook_edit.text().strip()

        self.config.dungeon_rooms = self._names(self.dungeon_rooms_edit.text(), self.config.dungeon_rooms)
        self.config.dungeon_shrines = self._names(self.dungeon_shrines_edit.text(), self.config.dungeon_shrines)
        self.config.dungeon_shop = self._names(self.dungeon_shop_edit.text(), self.config.dungeon_shop)
        self.config.dungeon_shop_limit = self.shop_limit_spin.value()
        self.config.dungeon_chests = self.chests_combo.currentText()
        self.config.dungeon_heart_stop = self.heart_stop_spin.value()

    @staticmethod
    def _names(text: str, fallback: list[str]) -> list[str]:
        names = [item.strip() for item in text.split(",") if item.strip()]
        return names or list(fallback)

    def _on_mode_changed(self, index: int) -> None:
        self.mode_stack.setCurrentIndex(max(0, index))
        self.config.mode = self.mode_combo.currentText()
        self._populate_maps()
        self._update_mode_visibility()

    def _detect_map_now(self) -> None:
        """Read the map name from the live game window and select its config."""
        if self.mode_combo.currentText() == "Dungeon":
            return
        if window.find_game_window() is None:
            QMessageBox.warning(
                self, "Roblox not found", "Open Anime Adventures and keep its window visible."
            )
            return
        if not vision.available():
            QMessageBox.warning(
                self,
                "OCR unavailable",
                "Map detection uses Apple Vision OCR, which is only available in the macOS build.",
            )
            return

        self.statusBar().showMessage("Reading the map name…")
        view = GameView()
        view.target()
        try:
            match = mapscan.read_map(view, mode=self.mode_combo.currentText())
        except Exception as exc:  # a failed screenshot must not close the app
            self._log(f"Detect map failed: {exc}")
            self.statusBar().showMessage("Idle", 4000)
            return

        if match is None:
            self._log(
                "Detect map: no stage name on screen yet. Open the map or stage select "
                "screen and try again."
            )
            self.statusBar().showMessage("Idle", 4000)
            return

        mode_index = self.mode_combo.findText(match.config.mode)
        if mode_index >= 0 and mode_index != self.mode_combo.currentIndex():
            self.mode_combo.setCurrentIndex(mode_index)  # also repopulates the map list
        else:
            self._populate_maps()

        wanted = f"{match.config.mode} · {match.config.map_name}"
        index = self.map_combo.findText(wanted)
        if index >= 0:
            self.map_combo.setCurrentIndex(index)
        self._sync_config()
        self._log(
            f"Detect map: {wanted} · read “{match.text.strip()}” ({match.score:.0%} match)"
        )
        self.statusBar().showMessage(f"Map: {match.config.map_name}", 6000)

    def _update_mode_visibility(self) -> None:
        self.vote_row_widget.setVisible(self.mode_combo.currentText() == "Infinite")

    def _refresh_units(self) -> None:
        by_slot = {unit.slot: unit for unit in self.config.units}
        for card in self.unit_cards:
            settings = by_slot.get(card.slot)
            if settings is not None:
                card.load(settings)

    def _update_record(self) -> None:
        wins = self.config.wins_total
        losses = self.config.losses_total
        total = wins + losses
        rate = f"{wins * 100 / total:.0f}%" if total else "—"
        self.record_label.setText(f"W {wins} · L {losses} · {rate}")

    def _refresh_setup_labels(self) -> None:
        self.start_clicks_label.setText(str(len(self.config.start_clicks)))
        self.vote_clicks_label.setText(str(len(self.config.vote_clicks)))

    def _refresh_table(self) -> None:
        self.game_panel.set_placements(self.config.placements)
        if self._game_window is not None:
            self._game_window.panel.set_placements(self.config.placements)
        self.table.setRowCount(len(self.config.placements))
        for row, placement in enumerate(self.config.placements):
            slot_item = QTableWidgetItem(str(placement.slot))
            slot_item.setTextAlignment(Qt.AlignCenter)
            position_item = QTableWidgetItem(f"{placement.x:.1%}, {placement.y:.1%}")
            upgrades_item = QTableWidgetItem(str(placement.upgrades))
            upgrades_item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(row, 0, slot_item)
            self.table.setItem(row, 1, position_item)
            self.table.setItem(row, 2, upgrades_item)

    def _selected_placement(self) -> int:
        model = self.table.selectionModel()
        rows = model.selectedRows() if model else []
        return rows[0].row() if rows else -1

    # --------------------------------------------------------------- editing

    def _add_start_click(self) -> None:
        self._pick_point("Click the button that opens your mode/map", self._store_start_click)

    def _store_start_click(self, point) -> None:
        relative = self._relative_point(point)
        if relative is None:
            return
        self.config.start_clicks.append(relative)
        self._refresh_setup_labels()
        self._log(f"Start click {len(self.config.start_clicks)}: {relative[0]:.1%}, {relative[1]:.1%}")

    def _clear_start_clicks(self) -> None:
        self.config.start_clicks.clear()
        self._refresh_setup_labels()

    def _add_vote_click(self) -> None:
        self._pick_point("Click the Lose / Give up vote option", self._store_vote_click)

    def _store_vote_click(self, point) -> None:
        relative = self._relative_point(point)
        if relative is None:
            return
        self.config.vote_clicks.append(relative)
        self._refresh_setup_labels()
        self._log(f"Vote click {len(self.config.vote_clicks)}: {relative[0]:.1%}, {relative[1]:.1%}")

    def _clear_vote_clicks(self) -> None:
        self.config.vote_clicks.clear()
        self._refresh_setup_labels()

    def _pick_point(self, message: str, callback) -> None:
        if window.find_game_window() is None:
            QMessageBox.warning(
                self, "Roblox not found", "Open Anime Adventures and keep its window visible."
            )
            return
        picker = PointPicker(self, message)
        picker.picked.connect(callback)
        picker.show()

    def _relative_point(self, point) -> list[float] | None:
        if point is None:
            return None
        found = window.find_game_window()
        if found is None or not found.rect.contains(point.x(), point.y()):
            QMessageBox.warning(self, "Outside the game", "Pick a point inside the Roblox window.")
            return None
        fx, fy = found.rect.to_relative(point.x(), point.y())
        return [fx, fy]

    def _hotkey_changed(self) -> None:
        spec = self.hotkey_edit.keySequence().toString(QKeySequence.PortableText).strip() or "]"
        self.config.start_hotkey = spec
        self._hotkeys.set_start_key(spec)
        self._install_shortcuts()
        self.start_button.setText(f"Start  ({spec})")
        self._log(f"Start hotkey set to {spec} (Esc still stops a run).")

    def _install_shortcuts(self) -> None:
        for shortcut in self._shortcuts:
            shortcut.setParent(None)
            shortcut.deleteLater()
        self._shortcuts = []

        spec = self.config.start_hotkey or "]"
        for sequence, handler in ((spec, self._toggle_run), ("Esc", self._stop_run)):
            shortcut = QShortcut(QKeySequence(sequence), self)
            shortcut.activated.connect(handler)
            self._shortcuts.append(shortcut)

    def _toggle_game_window(self) -> None:
        if self._game_window is None:
            self._game_window = GameWindow(self)
            self._game_window.clicked.connect(self._panel_click)
            self._game_window.panel.set_placements(self.config.placements)
        self._game_window.show()
        self._game_window.raise_()
        self._game_window.activateWindow()

    def _screen_check(self) -> None:
        """Log exactly what the macro can see, for diagnosing Play/map detection."""
        found = window.find_game_window()
        if found is None:
            self._log("Screen check: Roblox window not found.")
            seen = window.list_windows()
            self._log(
                "Screen check: windows it can see: " + (" | ".join(seen) if seen else "(none — Screen Recording not granted?)")
            )
            return
        rect = found.rect
        self._log(f"Screen check: Roblox {rect.width}×{rect.height} at ({rect.left}, {rect.top})")

        frame = screen.capture(rect, window.scale_at(*rect.center))
        if frame is None:
            self._log("Screen check: screenshot FAILED — grant Screen Recording to the app running CapyMacro.")
            return
        self._log(f"Screen check: captured {frame.shape[1]}×{frame.shape[0]} px")

        if not vision.available():
            self._log("Screen check: Apple Vision OCR is unavailable on this machine.")
            return
        lines = vision.read_text(frame)
        if lines:
            self._log(f"Screen check: OCR read {len(lines)} line(s): " + " | ".join(lines[:12]))
        else:
            self._log("Screen check: OCR read nothing — is a game screen actually visible?")

    def _arm_panel(self, action: str) -> None:
        self._panel_action = action
        labels = {
            "placement": "Placement — click the unit spot in the game view.",
            "start": "Start click — click the menu button in the game view, in order.",
            "vote": "Vote click — click the Lose vote option in the game view.",
        }
        self.panel_hint.setText(labels.get(action, ""))
        self._log(f"Live view: {labels.get(action, action)}")

    def _panel_click(self, fx: float, fy: float) -> None:
        """A click on the live game view records a point without leaving the app."""
        action = self._panel_action
        self._panel_action = None
        self.panel_hint.setText("Pick an action, then click the game view.")

        if action == "placement":
            dialog = PlacementDialog(self, point=[fx, fy])
            if dialog.exec() != QDialog.Accepted:
                return
            self.config.placements.append(dialog.placement())
            self._refresh_table()
            self._log(f"Placement added from the live view at {fx:.1%}, {fy:.1%}")
        elif action == "start":
            self.config.start_clicks.append([fx, fy])
            self._refresh_setup_labels()
            self._log(f"Start click {len(self.config.start_clicks)}: {fx:.1%}, {fy:.1%}")
        elif action == "vote":
            self.config.vote_clicks.append([fx, fy])
            self._refresh_setup_labels()
            self._log(f"Vote click {len(self.config.vote_clicks)}: {fx:.1%}, {fy:.1%}")
        else:
            self._log(f"Live view point: {fx:.1%}, {fy:.1%}")

    def _add_placement(self) -> None:
        dialog = PlacementDialog(self)
        if dialog.exec() != QDialog.Accepted:
            return
        self.config.placements.append(dialog.placement())
        self._refresh_table()

    def _add_circle(self) -> None:
        dialog = CircleDialog(self, defaults=self._circle_defaults)
        if dialog.exec() != QDialog.Accepted:
            return
        self._circle_defaults = dialog.values()
        placements = dialog.placements()
        if not placements:
            return
        self.config.placements.extend(placements)
        self._refresh_table()
        self._log(f"Added {len(placements)} circle placement(s).")

    def _edit_placement(self) -> None:
        row = self._selected_placement()
        if not 0 <= row < len(self.config.placements):
            return
        dialog = PlacementDialog(self, self.config.placements[row])
        if dialog.exec() != QDialog.Accepted:
            return
        self.config.placements[row] = dialog.placement()
        self._refresh_table()

    def _remove_placement(self) -> None:
        row = self._selected_placement()
        if not 0 <= row < len(self.config.placements):
            return
        del self.config.placements[row]
        self._refresh_table()

    def _clear_placements(self) -> None:
        if not self.config.placements:
            return
        self.config.placements.clear()
        self._refresh_table()

    # ------------------------------------------------------------------- runs

    def _toggle_run(self) -> None:
        if self._engine is not None and self._engine.is_running():
            self._stop_run()
        else:
            self._start_run()

    def _start_run(self) -> None:
        if self._engine is not None and self._engine.is_running():
            return

        self._sync_config()
        self._save_config(verbose=False)

        if window.find_game_window() is None:
            QMessageBox.warning(
                self, "Roblox not found", "Open Anime Adventures and keep its window visible."
            )
            return
        if not self.config.placements and not self.config.start_clicks and not self.config.auto_play:
            QMessageBox.information(
                self,
                "Nothing to do yet",
                "Add your start clicks (the buttons that open the map) or turn on automatic "
                "Play, and add at least one unit placement.",
            )
            return

        self._session_started = time.time()
        self._last_stats = {}
        engine = FarmEngine(
            self.config,
            on_log=self.logged.emit,
            on_stats=self.stats_updated.emit,
            on_finished=self.run_finished.emit,
        )
        self._engine = engine

        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self._hotkeys.start_escape()
        self.statusBar().showMessage("Running…")
        self._log(
            f"Starting {self.config.mode} · {self.config.map_name}"
            + (" (dry run)" if self.config.dry_run else "")
        )
        engine.start()

    def _stop_run(self) -> None:
        if self._engine is not None and self._engine.is_running():
            self._log("Stopping…")
            self._engine.stop()

    def _on_finished(self, ok: bool, message: str) -> None:
        wins = int(self._last_stats.get("wins", 0))
        losses = int(self._last_stats.get("losses", 0))
        if wins or losses:
            self.config.wins_total += wins
            self.config.losses_total += losses
            self._update_record()
            self._save_config(verbose=False)

        self._engine = None
        self._hotkeys.stop_escape()
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.statusBar().showMessage(message, 6000)
        self._log(("✔ " if ok else "✖ ") + message)

        if self.config.webhook:
            session = Session(
                map_name=self.config.map_name,
                started_at=self._session_started,
                runs=self._last_stats.get("runs", 0),
                wins=self._last_stats.get("wins", 0),
                losses=self._last_stats.get("losses", 0),
            )
            post_webhook(self.config.webhook, session_embed(session))

    def _on_stats(self, stats: dict) -> None:
        self._last_stats = stats
        self.statusBar().showMessage(
            f"Runs {stats.get('runs', 0)} · Wins {stats.get('wins', 0)} · "
            f"Losses {stats.get('losses', 0)} · {stats.get('duration', '0m 0s')}"
        )

    # ------------------------------------------------------------------ misc

    def _log(self, message: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_view.appendPlainText(f"[{stamp}] {message}")

    def _refresh_window(self) -> None:
        found = window.find_game_window()
        if found is None:
            self.window_label.setText("Roblox not found — open Anime Adventures")
        else:
            rect = found.rect
            self.window_label.setText(f"Roblox: {rect.width}×{rect.height} at ({rect.left}, {rect.top})")

    def _save_config(self, verbose: bool) -> None:
        self._sync_config()
        try:
            save_json(CONFIG_PATH, self.config.to_dict())
        except Exception as exc:
            self._log(f"Could not save config: {exc}")
            return
        if verbose:
            self._log(f"Saved {CONFIG_PATH}")

    def _show_permissions(self) -> None:
        accessibility = permissions.describe(permissions.accessibility_granted())
        recording = permissions.describe(permissions.screen_recording_granted())
        monitoring = permissions.describe(permissions.input_monitoring_granted())

        dialog = QDialog(self)
        dialog.setWindowTitle("macOS permissions")
        dialog.setMinimumWidth(580)
        layout = QVBoxLayout(dialog)

        intro = QLabel("CapyMacro needs three permissions in System Settings → Privacy & Security:")
        intro.setWordWrap(True)
        layout.addWidget(intro)

        status = QLabel(
            f"• Screen Recording — {recording}\n"
            f"• Accessibility — {accessibility}\n"
            f"• Input Monitoring — {monitoring}"
        )
        status.setWordWrap(True)
        layout.addWidget(status)

        warning = QLabel(
            "macOS has no command that grants these: the switch has to be turned on by hand, "
            "and the app only appears in the list after it has asked once."
        )
        warning.setWordWrap(True)
        layout.addWidget(warning)

        instructions = QPlainTextEdit()
        instructions.setReadOnly(True)
        instructions.setMinimumHeight(200)
        instructions.setPlainText(
            "1. Press “Ask macOS”. The system prompt registers the app that started\n"
            "   CapyMacro in all three lists.\n"
            f"2. That app is: {permissions.host_app()}\n"
            f"   (this Python: {sys.executable})\n"
            "   • started with launch.command or from Terminal → grant Terminal\n"
            "   • started from iTerm → grant iTerm\n"
            "3. The + button in those panes only accepts .app bundles — that is why the\n"
            "   files in the macro folder are greyed out. Press “Create CapyMacro.app”\n"
            "   below, then use + and pick CapyMacro.app (it sits next to run.sh), and\n"
            "   switch it on in all three panes.\n"
            "4. Launch CapyMacro by double-clicking that app (quit this Terminal copy\n"
            "   first with ⌘Q) so the permissions apply to the running app.\n\n"
            "Granting Terminal instead also works — it is what runs the macro when\n"
            "you start it with launch.command.\n\n"
            "Commands that open the panes (they cannot grant anything):\n"
            f"{permissions.PANE_COMMANDS}"
        )
        layout.addWidget(instructions)

        buttons = QHBoxLayout()
        ask = QPushButton("Ask macOS")
        ask.clicked.connect(self._ask_permissions)
        buttons.addWidget(ask)
        for text, pane in (
            ("Accessibility", permissions.ACCESSIBILITY_PANE),
            ("Screen Recording", permissions.SCREEN_PANE),
            ("Input Monitoring", permissions.INPUT_PANE),
        ):
            button = QPushButton(text)
            button.clicked.connect(lambda _checked=False, p=pane: permissions.open_settings(p))
            buttons.addWidget(button)
        create = QPushButton("Create CapyMacro.app")
        create.setToolTip("Make a double-clickable app next to run.sh, for the + picker in System Settings.")
        create.clicked.connect(self._create_app)
        buttons.addWidget(create)
        buttons.addStretch(1)
        close = QPushButton("Close")
        close.clicked.connect(dialog.accept)
        buttons.addWidget(close)
        layout.addLayout(buttons)

        dialog.exec()

    def _create_app(self) -> None:
        try:
            path = bundle.create_app_bundle()
        except Exception as exc:
            self._log(f"Could not create CapyMacro.app: {exc}")
            return
        self._log(
            f"Created {path}. Add CapyMacro to Accessibility, Screen Recording and "
            "Input Monitoring, then launch it from Finder (quit this copy first)."
        )
        permissions.reveal(path)

    def _ask_permissions(self) -> None:
        permissions.request_all()
        self._log(
            "Asked macOS for Screen Recording, Accessibility and Input Monitoring — "
            f"grant them to {permissions.host_app()}, then restart CapyMacro."
        )
        permissions.open_settings()

    def _show_about(self) -> None:
        QMessageBox.about(
            self,
            "About CapyMacro",
            "<b>CapyMacro</b><br>Anime Adventures on macOS<br><br>"
            "Screen-driven farming for Infinite, the Summer event and Dungeons: it places "
            "your units (including circle patterns), follows your dungeon priorities, "
            "reconnects, and pauses for human-verification prompts instead of clicking through them.",
        )

    def closeEvent(self, event) -> None:
        if self._engine is not None:
            self._engine.stop()
        self._hotkeys.stop()
        self._save_config(verbose=False)
        super().closeEvent(event)
