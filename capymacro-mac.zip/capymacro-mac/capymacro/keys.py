"""Keyboard and mouse injection through Quartz, with no keyboard-layout lookup.

pynput asks Text Services Manager (``TSMGetInputSourceProperty``) which character
a key produces. On macOS 26 that call traps unless it runs on the main queue, so
pynput's listener/controller in a background thread crashed the app with SIGTRAP
(``dispatch_assert_queue_fail``). These are fixed hardware keycodes, so nothing
asks the system about layouts and the calls are safe from any thread.
"""

from __future__ import annotations

import time

try:  # macOS only
    import Quartz
except Exception:  # pragma: no cover - non-macOS development machines
    Quartz = None

# US ANSI virtual keycodes (kVK_*), the same numbers CGEvent uses.
KEYCODES = {
    "a": 0, "s": 1, "d": 2, "f": 3, "h": 4, "g": 5, "z": 6, "x": 7, "c": 8, "v": 9,
    "b": 11, "q": 12, "w": 13, "e": 14, "r": 15, "y": 16, "t": 17,
    "1": 18, "2": 19, "3": 20, "4": 21, "6": 22, "5": 23, "=": 24, "9": 25,
    "7": 26, "-": 27, "8": 28, "0": 29, "]": 30, "o": 31, "u": 32, "[": 33,
    "i": 34, "p": 35, "return": 36, "enter": 36, "l": 37, "j": 38, "'": 39,
    "k": 40, ";": 41, "\\": 42, ",": 43, "/": 44, "n": 45, "m": 46, ".": 47,
    "tab": 48, "space": 49, "`": 50, "backspace": 51, "delete": 51,
    "escape": 53, "esc": 53,
    "f1": 122, "f2": 120, "f3": 99, "f4": 118, "f5": 96, "f6": 97,
    "f7": 98, "f8": 100, "f9": 101, "f10": 109, "f11": 103, "f12": 111,
    "left": 123, "right": 124, "down": 125, "up": 126,
    "home": 115, "end": 119, "pageup": 116, "pagedown": 121,
}


def available() -> bool:
    return Quartz is not None


def keycode(key: str) -> int | None:
    """Hardware keycode for a key name ("w", "1", "]", "escape", "f5")."""
    return KEYCODES.get((key or "").strip().lower())


def key_down(key: str) -> bool:
    code = keycode(key)
    if code is None or Quartz is None:
        return False
    event = Quartz.CGEventCreateKeyboardEvent(None, code, True)
    if event is None:
        return False
    Quartz.CGEventPost(Quartz.kCGHIDEventTap, event)
    return True


def key_up(key: str) -> bool:
    code = keycode(key)
    if code is None or Quartz is None:
        return False
    event = Quartz.CGEventCreateKeyboardEvent(None, code, False)
    if event is None:
        return False
    Quartz.CGEventPost(Quartz.kCGHIDEventTap, event)
    return True


def press(key: str, pause: float = 0.02) -> bool:
    if not key_down(key):
        return False
    if pause:
        time.sleep(pause)
    return key_up(key)


def click(x: float, y: float, pause: float = 0.03) -> bool:
    """Move to ``x, y`` in screen points and click the left button."""
    if Quartz is None:
        return False
    point = (float(x), float(y))

    move = Quartz.CGEventCreateMouseEvent(
        None, Quartz.kCGEventMouseMoved, point, Quartz.kCGMouseButtonLeft
    )
    down = Quartz.CGEventCreateMouseEvent(
        None, Quartz.kCGEventLeftMouseDown, point, Quartz.kCGMouseButtonLeft
    )
    up = Quartz.CGEventCreateMouseEvent(
        None, Quartz.kCGEventLeftMouseUp, point, Quartz.kCGMouseButtonLeft
    )
    if move is None or down is None or up is None:
        return False

    Quartz.CGEventPost(Quartz.kCGHIDEventTap, move)
    if pause:
        time.sleep(pause)
    Quartz.CGEventPost(Quartz.kCGHIDEventTap, down)
    Quartz.CGEventPost(Quartz.kCGHIDEventTap, up)
    return True
