"""A live, clickable view of the Roblox window, inside the CapyMacro window."""

from __future__ import annotations

import cv2
from PySide6.QtCore import QRect, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import QVBoxLayout, QWidget

from .. import screen, window

AMBER = QColor(242, 193, 78, 240)
BORDER = QColor(90, 86, 78)
INK = QColor(24, 22, 18, 230)


class GamePanel(QWidget):
    """Mirror of the game window; a click reports a window-relative point."""

    clicked = Signal(float, float)

    def __init__(self, parent=None, interval_ms: int = 400):
        super().__init__(parent)
        self.setMinimumSize(320, 210)
        self.setCursor(Qt.CrossCursor)
        self.setToolTip(
            "Live view of the Roblox window. Click it to record a point — the position "
            "is saved relative to the window, so resizing Roblox later keeps it valid."
        )
        self._pixmap: QPixmap | None = None
        self._placements: list = []
        self._status = "Looking for Roblox…"
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(max(150, int(interval_ms)))

    def set_placements(self, placements) -> None:
        self._placements = list(placements or [])
        self.update()

    def refresh(self) -> None:
        if not self.isVisible():
            return

        found = window.find_game_window()
        if found is None:
            self._pixmap = None
            self._status = "Roblox not found — open Anime Adventures"
            self.update()
            return

        rect = found.rect
        frame = screen.capture(rect, window.scale_at(*rect.center))
        if frame is None:
            self._pixmap = None
            self._status = "Cannot capture Roblox — grant Screen Recording permission"
            self.update()
            return

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        image = QImage(
            rgb.data,
            rgb.shape[1],
            rgb.shape[0],
            int(rgb.strides[0]),
            QImage.Format_RGB888,
        ).copy()
        self._pixmap = QPixmap.fromImage(image)
        self._status = f"{rect.width}×{rect.height} · click to record a point"
        self.update()

    def _image_rect(self) -> QRect:
        if self._pixmap is None or self._pixmap.isNull():
            return QRect()
        area = self.rect().adjusted(1, 1, -1, -1)
        scaled = self._pixmap.size().scaled(area.size(), Qt.KeepAspectRatio)
        x = area.left() + (area.width() - scaled.width()) // 2
        y = area.top() + (area.height() - scaled.height()) // 2
        return QRect(x, y, scaled.width(), scaled.height())

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(18, 17, 15))

        image_rect = self._image_rect()
        if self._pixmap is not None and not image_rect.isNull():
            painter.drawPixmap(image_rect, self._pixmap)
            painter.setPen(QPen(BORDER, 1))
            painter.drawRect(image_rect.adjusted(0, 0, -1, -1))

            font = QFont()
            font.setPixelSize(10)
            font.setBold(True)
            painter.setFont(font)
            for index, placement in enumerate(self._placements, start=1):
                x = image_rect.left() + placement.x * image_rect.width()
                y = image_rect.top() + placement.y * image_rect.height()
                painter.setPen(QPen(QColor(255, 255, 255, 230), 1))
                painter.setBrush(AMBER)
                painter.drawEllipse(int(x) - 5, int(y) - 5, 10, 10)
                painter.setPen(INK)
                painter.drawText(int(x) - 5, int(y) - 5, 10, 10, int(Qt.AlignCenter), str(index))
        else:
            painter.setPen(QColor(200, 195, 185))
            painter.drawText(self.rect(), int(Qt.AlignCenter), self._status)
            return

        painter.setPen(QColor(200, 195, 185))
        font = QFont()
        font.setPixelSize(10)
        painter.setFont(font)
        painter.drawText(
            self.rect().adjusted(6, 0, -6, -2),
            int(Qt.AlignLeft | Qt.AlignBottom),
            self._status,
        )

    def mousePressEvent(self, event) -> None:
        if event.button() != Qt.LeftButton:
            return
        image_rect = self._image_rect()
        position = event.position()
        if image_rect.isNull() or not image_rect.contains(position.toPoint()):
            return
        fx = (position.x() - image_rect.left()) / max(1, image_rect.width())
        fy = (position.y() - image_rect.top()) / max(1, image_rect.height())
        self.clicked.emit(min(1.0, max(0.0, fx)), min(1.0, max(0.0, fy)))


class GameWindow(QWidget):
    """The live view in its own always-on-top window, for a second screen."""

    clicked = Signal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent, Qt.Window)
        self.setWindowTitle("CapyMacro — Roblox view")
        self.setAttribute(Qt.WA_DeleteOnClose, False)
        self.resize(960, 600)
        self.panel = GamePanel(self)
        self.panel.clicked.connect(self.clicked)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.panel)
