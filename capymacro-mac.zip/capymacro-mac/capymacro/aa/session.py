"""Session stats, persistence and Discord webhook summaries."""

from __future__ import annotations

import json
import threading
import time
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Session:
    map_name: str = ""
    started_at: float = field(default_factory=time.time)
    runs: int = 0
    wins: int = 0
    losses: int = 0
    gems: int = 0

    @property
    def duration(self) -> float:
        return time.time() - self.started_at

    def summary(self) -> dict:
        minutes, seconds = divmod(int(self.duration), 60)
        return {
            "map": self.map_name,
            "runs": self.runs,
            "wins": self.wins,
            "losses": self.losses,
            "duration": f"{minutes}m {seconds}s",
        }


def post_webhook(url: str, payload: dict, timeout: float = 10.0) -> bool:
    """POST a JSON payload to a Discord webhook, off the caller's thread."""
    if not url:
        return False

    def _send() -> None:
        request = urllib.request.Request(
            url,
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json", "User-Agent": "CapyMacro/0.1"},
        )
        try:
            urllib.request.urlopen(request, timeout=timeout).read()
        except Exception:
            pass

    threading.Thread(target=_send, name="capymacro-webhook", daemon=True).start()
    return True


def session_embed(session: Session) -> dict:
    data = session.summary()
    return {
        "embeds": [
            {
                "title": "CapyMacro session",
                "color": 0xF2C14E,
                "fields": [
                    {"name": "Map", "value": data["map"] or "—", "inline": True},
                    {"name": "Runs", "value": str(data["runs"]), "inline": True},
                    {"name": "Time", "value": data["duration"], "inline": True},
                    {"name": "Wins", "value": str(data["wins"]), "inline": True},
                    {"name": "Losses", "value": str(data["losses"]), "inline": True},
                ],
            }
        ]
    }


def save_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def load_json(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}
