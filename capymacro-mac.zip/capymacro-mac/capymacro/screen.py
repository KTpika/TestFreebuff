"""Screen capture and template matching, all in window points."""

from __future__ import annotations

import threading
from dataclasses import dataclass
from pathlib import Path

import cv2
import mss
import numpy as np

from .coords import Rect

# The shipped templates were captured at the Windows app's UI scale, so a
# MacBook window can sit well above or below it. Search is coarse, then refined
# around the best hit, with an early exit once a match is convincing.
SCALES = tuple(round(0.60 + 0.10 * step, 2) for step in range(15))
REFINE = (0.02, -0.02, 0.04, -0.04, 0.06, -0.06)
EARLY_EXIT = 0.93

_local = threading.local()
_cache: dict[tuple[str, float], np.ndarray] = {}


def _grabber() -> "mss.mss":
    grabber = getattr(_local, "grabber", None)
    if grabber is None:
        grabber = mss.mss()
        _local.grabber = grabber
    return grabber


def capture(rect: Rect, scale: float = 1.0) -> np.ndarray | None:
    """Grab ``rect`` and return a BGR image whose size matches it in points."""
    if rect.width <= 0 or rect.height <= 0:
        return None

    scale = scale if scale > 0 else 1.0
    region = {
        "left": int(round(rect.left * scale)),
        "top": int(round(rect.top * scale)),
        "width": max(1, int(round(rect.width * scale))),
        "height": max(1, int(round(rect.height * scale))),
    }

    try:
        shot = _grabber().grab(region)
    except Exception:
        return None

    image = np.asarray(shot, dtype=np.uint8)
    if image.ndim != 3 or image.shape[2] < 3:
        return None
    image = np.ascontiguousarray(image[:, :, :3])

    if image.shape[1] != rect.width or image.shape[0] != rect.height:
        image = cv2.resize(image, (rect.width, rect.height), interpolation=cv2.INTER_AREA)

    return np.ascontiguousarray(image)


def load_template(path: str | Path) -> np.ndarray | None:
    """Read a template PNG/JPG, caching it until the file changes."""
    target = Path(path).expanduser()
    try:
        if not target.is_file():
            return None
        key = (str(target.resolve()), target.stat().st_mtime)
    except OSError:
        return None

    cached = _cache.get(key)
    if cached is not None:
        return cached

    try:
        data = np.fromfile(str(target), dtype=np.uint8)
        image = cv2.imdecode(data, cv2.IMREAD_COLOR)
    except Exception:
        return None
    if image is None:
        return None

    if len(_cache) > 32:
        _cache.clear()
    _cache[key] = image
    return image


def save_image(path: str | Path, image: np.ndarray) -> bool:
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    suffix = target.suffix or ".png"
    ok, buffer = cv2.imencode(suffix, image)
    if not ok:
        return False
    buffer.tofile(str(target))
    return True


@dataclass(frozen=True)
class Match:
    x: int
    y: int
    score: float
    scale: float


def _match_at(haystack: np.ndarray, template: np.ndarray, factor: float) -> Match | None:
    frame_height, frame_width = haystack.shape[:2]
    if factor == 1.0:
        candidate = template
    else:
        candidate = cv2.resize(template, None, fx=factor, fy=factor, interpolation=cv2.INTER_AREA)

    height, width = candidate.shape[:2]
    if width < 4 or height < 4 or width > frame_width or height > frame_height:
        return None

    result = cv2.matchTemplate(haystack, candidate, cv2.TM_CCOEFF_NORMED)
    _, score, _, location = cv2.minMaxLoc(result)
    if not np.isfinite(score):
        return None
    return Match(
        x=int(location[0] + width // 2),
        y=int(location[1] + height // 2),
        score=float(score),
        scale=float(factor),
    )


def find_template(
    haystack: np.ndarray,
    template: np.ndarray,
    scales=SCALES,
    threshold: float = 0.0,
    hint: float | None = None,
) -> Match | None:
    """Best template match centre, at whichever scale scores highest.

    ``hint`` is the scale that matched last time; trying it first makes repeat
    lookups a single correlation pass. ``threshold`` short-circuits the search.
    """
    if haystack is None or template is None:
        return None

    ordered: list[float] = []
    for factor in (hint, 1.0, *scales):
        if factor is None:
            continue
        factor = round(float(factor), 3)
        if factor not in ordered and factor > 0:
            ordered.append(factor)

    goal = max(float(threshold), EARLY_EXIT)
    best: Match | None = None

    for factor in ordered:
        match = _match_at(haystack, template, factor)
        if match is None:
            continue
        if best is None or match.score > best.score:
            best = match
        if best.score >= goal:
            return best

    if best is not None and best.scale:
        for offset in REFINE:
            factor = round(best.scale + offset, 3)
            match = _match_at(haystack, template, factor)
            if match is not None and match.score > best.score:
                best = match
                if best.score >= goal:
                    break

    return best
