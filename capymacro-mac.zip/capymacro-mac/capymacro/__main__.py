"""Allow `python -m capymacro`."""

from .app import main

raise SystemExit(main())
