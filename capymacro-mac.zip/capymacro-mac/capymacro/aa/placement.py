"""Automatic placement patterns (circles and centre-out rings)."""

from __future__ import annotations

import math


def ring_points(
    center_x: float,
    center_y: float,
    count: int,
    radius_x: float,
    radius_y: float | None = None,
    start_angle: float = -90.0,
) -> list[tuple[float, float]]:
    """``count`` points evenly spaced on one ellipse, clockwise from ``start_angle``."""
    count = max(0, int(count))
    if count == 0:
        return []
    if radius_y is None:
        radius_y = radius_x
    if count == 1:
        return [(center_x, center_y)]

    points: list[tuple[float, float]] = []
    for index in range(count):
        angle = math.radians(start_angle + 360.0 * index / count)
        points.append(
            (
                center_x + math.cos(angle) * radius_x,
                center_y + math.sin(angle) * radius_y,
            )
        )
    return points


def center_out_points(
    center_x: float,
    center_y: float,
    count: int,
    radius_x: float,
    radius_y: float | None = None,
    rings: int | None = None,
    start_angle: float = -90.0,
) -> list[tuple[float, float]]:
    """A centre point, then growing rings around it."""
    count = max(0, int(count))
    if count == 0:
        return []
    if radius_y is None:
        radius_y = radius_x
    if count == 1:
        return [(center_x, center_y)]

    if rings is None:
        rings = 1 if count <= 7 else 2 if count <= 14 else 3
    rings = max(1, min(int(rings), count - 1))

    remaining = count - 1
    weights = list(range(1, rings + 1))
    total = sum(weights)
    shares = [max(1, int(round(remaining * weight / total))) for weight in weights]

    while sum(shares) > remaining:
        for index in range(len(shares) - 1, -1, -1):
            if sum(shares) <= remaining:
                break
            if shares[index] > 1:
                shares[index] -= 1
    while sum(shares) < remaining:
        shares[-1] += 1

    points: list[tuple[float, float]] = [(center_x, center_y)]
    for index, share in enumerate(shares):
        factor = (index + 1) / rings
        offset = 180.0 / max(share, 1) if index % 2 else 0.0
        points.extend(
            ring_points(
                center_x,
                center_y,
                share,
                radius_x * factor,
                radius_y * factor,
                start_angle + offset,
            )
        )

    return points[:count]


def cycle_slots(count: int, start: int = 1, max_slot: int = 6) -> list[int]:
    """Unit slot for each point of a ring, cycling 1→2→…→max_slot→1."""
    count = max(0, int(count))
    start = max(1, min(int(max_slot), int(start)))
    return [((start - 1 + index) % max_slot) + 1 for index in range(count)]


PATTERNS = {
    "Ring": ring_points,
    "Center out": center_out_points,
}
