#!/usr/bin/env bash
# Opens the three macOS privacy panes CapyMacro needs.
# macOS does not allow a script to grant these permissions — SIP protects the
# switches, so the only supported way is to flip them by hand in System Settings.

set -u

open "x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture" >/dev/null 2>&1 || true
sleep 1
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility" >/dev/null 2>&1 || true
sleep 1
open "x-apple.systempreferences:com.apple.preference.security?Privacy_ListenEvent" >/dev/null 2>&1 || true

cat <<'TXT'

CapyMacro needs three switches on (System Settings → Privacy & Security):

  Screen Recording   so it can see the Roblox window (map + Play detection)
  Accessibility      so it can click and press unit keys
  Input Monitoring   so the ] start key works while Roblox is in front

No command can grant these. What to do:

  1. In the panes that just opened, find Terminal (or iTerm / Python) in the
     list. Not there? Click +, press Cmd+Shift+G, paste

         /Applications/Utilities/Terminal.app

     then Add, and switch it on. Repeat in all three panes.
  2. Quit CapyMacro (Cmd+Q) and start it again.

The app's own Permissions button (top of the window) shows the status of each
switch and has an "Ask macOS" prompt that registers the right app in the lists.
TXT

read -r -p "Press Return to close this window. " _ || true
