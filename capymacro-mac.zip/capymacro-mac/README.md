# CapyMacro — Anime Adventures on macOS

A macOS port of the **Capybara / Capy's Anime Adventures macro**. The Windows
release is a compiled AutoHotkey app, so this is a screen-driven rewrite rather
than a wrapper: it targets the Roblox window, reads the screen with the original
detection templates, and drives the game with real mouse and keyboard input.

Three modes: **Infinite gem farm**, **Summer event**, and **Dungeons**.

## What works today

- **Roblox window targeting** — finds the game window with Quartz, focuses it, and
  keeps all positions relative to it, so moving or resizing the window is fine.
- **Unit placements** — pick each spot on screen once, or generate a **circle**
  (ring or centre-out) around a chosen point; the macro presses the unit hotkey,
  clicks each position, and buys the upgrades you configured.
- **Unit cards** — six cards like the Windows app (Unit 1–6): Enabled, Placement
  priority, Upgrade priority, Placements, Upgrade limit (+ *Enable upgrade
  limit*), Auto ability and Hill. Units are placed in Placement-priority order
  and upgraded in Upgrade-priority order, and the limit caps upgrade clicks.
- **Win/loss calculator** — lifetime wins, losses and win rate in the header,
  updated after every match and saved with your setup.
- **Match loop** — after a win or loss it clicks through the rewards, returns to
  the **Lobby**, then **Play → walk (if set) → Find Match** for the next run (each
  step is OCR-driven and can be switched off). In the Summer "Join Matchmaking?"
  panel it presses **Find Match**, never **Play Here** (that starts a private run)
  and never the panel heading. If the queue is a place you walk into, **Walk
  forward after Play** holds `W` for the number of seconds you set — a straight
  timed walk, not pathfinding.
- **Summer event farming** — replays your Summer start clicks, presses Play, walks
  forward for the seconds you set, then finds and presses **Find Match** in the
  queue panel (on by default), plays each run and starts the next one.
- **Dungeon farming** — a room-by-room loop: click the highest-priority room label
  on screen, then handle whatever it opened (buy from the shop up to your per-shop
  limit, take the first preferred shrine, open reward chests now or at the end),
  advance on Next, pause when hearts get low, and click through every reward and
  chest panel when the run ends.
- **Captcha guard** — checks the screen about once a second and before every click.
  It recognises both the usual human-verification prompts and the numeric
  "type/enter the numbers you see" challenge. Input pauses, you get a notification
  and sound (repeated every 90 s while it stays up), and the macro resumes only
  after two consecutive clear screens. It never solves or types the challenge —
  it exists to prove a human is there, so you answer it and the macro carries on.
- **Wave detection with Apple Vision OCR** — reads the on-screen "Wave N" counter,
  so it votes at exactly the wave you set (6 by default).
- **Vote, collect, replay** — uses the shipped `vote-start`, `defeat`, `victory`,
  `replay`, `retry`, `reward-continue` and `next-level` templates to move through
  the end-of-run screens.
- **Auto Play** — after your start clicks (or on its own, if you have none) it
  reads Roblox's **Play / Play Again** button with OCR and presses it, so no extra
  recorded click is needed to enter the game.
- **Disconnect recovery** — watches for the game's disconnect dialog (the
  `title`, `idle-278` and `reconnect` templates plus OCR of "Disconnected",
  "Connection lost", "Error Code: 278/277/268"), clicks **Reconnect**, reopens your
  private-server link if the reconnect fails, presses Play, and starts the
  interrupted run again (an interrupted run is not counted as a completed run).
- **Live game view** — a mirror of the Roblox window inside the CapyMacro window:
  click a point on it to record a placement, a start click or a vote click without
  ever leaving the app, and see every saved placement drawn over the map.
- **Dry run** — logs every click and key press without touching the mouse.
- **Session stats + Discord webhook** — runs, wins, losses and session time.
- **58 map configs and 106 templates** imported from the Windows release, so map
  names, acts, difficulties and all detection images are the originals.

## Not ported yet

The rest of the paid feature list — portal tier/debuff scanning, daily and
half-hourly challenges, custom multi-map mode lists, team swap, config-sharing
codes and item/reward tracking — is not implemented. The engine, template library
and config format are in place for them; each one is a separate screen-flow build.

## Requirements

- macOS 12 or newer on Apple Silicon or Intel.
- [Roblox](https://www.roblox.com/download) with **Anime Adventures** installed.
- Python 3.10+ (`python3 --version`), from [python.org](https://www.python.org/downloads/macos/).

## Install and run

```bash
./run.sh
```

The first launch creates `.venv/` and installs the dependencies, then opens the
app. Later launches are instant; if `requirements.txt` ever changes (new macOS
frameworks are added from time to time) the launcher re-runs pip automatically
before starting. You can also double-click `launch.command` in
Finder.

## macOS permissions (once)

Under **System Settings → Privacy & Security**:

| Permission | Why |
| --- | --- |
| **Screen Recording** | to see the Roblox window and read the wave counter |
| **Accessibility** | to click, press unit hotkeys and receive the start key / Esc while Roblox is in front |
| **Input Monitoring** | not needed any more, but harmless to keep granted |

Grant them to the app you start CapyMacro from (Terminal, iTerm or
`.venv/bin/python`), then restart it. **Help → macOS permissions…** opens the
right pane. Without Accessibility, clicks silently do nothing.

## Working in PyCharm

The project is a plain Python package, so PyCharm can run and debug it directly:

1. **File → Open** and choose the `capymacro-mac` **folder** (not a file inside it).
2. **Settings → Project → Python Interpreter → Add Interpreter → Existing** and
   pick `.venv/bin/python` inside that folder. If `.venv` is missing, run
   `./run.sh` once (it creates it) and then choose it.
3. **Run → Edit Configurations → + → Python** and set **Module name** to
   `capymacro` (instead of a script path), **Working directory** to the project
   folder, and the interpreter from step 2. That is exactly `python -m capymacro`.
   `requirements.txt` is picked up automatically for the package list.
4. Permissions: when you start it from PyCharm, **PyCharm.app** is the app macOS
   lists, not Terminal. The **Permissions** dialog names it (`host_app` shows
   PyCharm), so grant Accessibility, Screen Recording and Input Monitoring to
   PyCharm, then restart PyCharm.
5. Debugging works normally (breakpoints in `capymacro/aa/farm.py`), but remember
   the farm engine runs on a background thread and sends real clicks.

## Setting up a farm

1. Open Roblox and Anime Adventures, and leave the window visible.
2. **Mode** — Infinite, Summer or Dungeon. **Map** — leave it on *Auto — detect on
   screen*: after the start clicks the macro reads the stage name off the game and
   uses that map's config, and the log says what it read. *Detect map* does the
   same once, right now, and selects the map in the list. You can still pick one
   of the 22 Infinite or 36 Summer maps by hand. Dungeon runs start from the
   entrance. Set the number of runs (`∞` runs until you stop).
3. **Start clicks** — press *Add click…* and click, in order, the buttons that
   take you from the lobby into an Infinite run (mode → map → play). These are
   replayed at the start of every run. One to five clicks is typical. With
   *Press the Play button automatically* ticked you can stop at the game page:
   the macro finds Play with OCR and presses it for you.
4. **Vote clicks** — add the click(s) that pick *Lose* in the vote screen, if your
   layout needs one after the vote button.
5. **Unit placements** — *Add placement…*: choose the unit slot (1–6), the number
   of upgrades, then *Pick on screen…* and click the map position. *Circle
   placement…* builds a ring: click the centre once, then *Pick edge…* and click
   the rim and the radius is measured for you. Numbered dots preview every spot
   live over the map (move the dialog aside to see them), quick counts (4/6/8/12)
   set the number of units, and the dialog remembers your last circle settings.
6. Press **]** (or **Start**). The start key is changeable under **Connection →
   Start hotkey**; **Esc** or **Stop** halts within a fraction of a second. Both
   work globally with Accessibility; inside the window the shortcut always works.

Tick **Dry run** first: the log lists everything it would do, so you can check
your points without the game reacting.

The setup is saved to `data/farm.json` when you start a run or quit.

### Live game view

The right-hand panel under **Roblox live view** mirrors the Roblox window about
2–3 times a second and draws every saved placement as a numbered dot. Press
*Placement*, *Start click* or *Vote click*, then click the spot in the view: the
point is stored relative to the game window, exactly like the full-screen picker.
This is a mirror, not an embedded copy of Roblox — macOS does not let one app put
another app's window inside itself — but it means you never lose the game while
recording and the view follows the window wherever it goes. **Pop out view** puts
the same mirror in its own always-on-top window (handy on a second display), and
clicks in either copy record points the same way. If the panel says it cannot
capture Roblox, Screen Recording permission is missing; **Screen check** in the
header logs exactly what the screenshot and OCR can see.

### Units

The **Units** tab is the per-unit grid: six cards, one per hotkey slot. On each
card, **Placement priority** and **Upgrade priority** order the work (lower
number first), **Placements** is how many copies of that unit to place (0 uses
every recorded position for it), and **Upgrade limit** caps upgrade clicks when
**Enable upgrade limit** is ticked. **Auto ability** presses the key set under
**Connection → Ability key** after that unit is placed. **Hill** is saved with
the unit for the original app's hill placements, but CapyMacro has no separate
hill spots yet, so it does not change anything.

Placing always happens first, in Placement-priority order; upgrades follow, in
Upgrade-priority order, so the team is on the map before any money is spent.

The **Walk forward after Play** setting on the Summer page holds `W` for the given
number of seconds once Play has been pressed (0 = off), and the macro presses
**Find Match** in the queue panel when the walk ends. It exists because the
Summer queue is entered by walking into a zone on some layouts. It is a fixed
timed walk — CapyMacro does not steer around obstacles or follow a path, so tune
the seconds once in the lobby and keep the camera pointed the right way.

### Circle placement

A new circle starts in the **middle of the Roblox window**, so picking a centre is
optional. **Pick edge…** measures the radius from one click, the numbered dots
preview every position, and **Give each position the next unit slot** (on by
default) walks unit slots 1 → 6 around the ring, so one circle covers a whole
team; turn it off to place the same unit at every position. The dialog reuses your
last circle settings next time.

### Permissions not listed in System Settings

There is **no command that grants these permissions** — macOS protects the
switches with SIP, so `tccutil` can only reset them and editing the database is
blocked. The switch has to be flipped by hand, and the app only appears in the
list after it has asked once.

1. Click **Permissions** at the top of the window (or **Help → macOS
   permissions…**) and press **Ask macOS**. The prompt registers the app that
   started CapyMacro in all three lists.
2. That app is **Terminal** if you use `launch.command` or a Terminal window, or
   **iTerm** if you start it from iTerm. Grant that one.
3. Still missing? In the pane press `+`, then `⌘⇧G`, paste
   `/Applications/Utilities/Terminal.app` (or the Python path shown in the dialog),
   Add, and switch it on.
4. Quit CapyMacro (`⌘Q`) and start it again.

`grant_permissions.command` (double-click) opens all three panes at once for this.
The commands inside it are just `open "x-apple.systempreferences:…"` — they open
the right pane, they cannot grant anything.

### The + picker greys out every file

That picker only accepts `.app` bundles, which is why the files in the macro
folder are not selectable. Press **Permissions → Create CapyMacro.app**: a small
`CapyMacro.app` is written next to `run.sh` and shown in Finder. Use `+` in each
pane and choose that app, switch it on in all three, then launch CapyMacro by
double-clicking it (quit the Terminal copy with `⌘Q` first) so the grant belongs
to the running app. Keep the bundle next to `run.sh` — it starts the app from
there.

### Dungeon priorities

Dungeon mode reads three comma-separated lists of template names, in priority
order — the first one visible on screen is chosen:

- **Rooms** (default `chests-title, shop-title, shrine-title, boss-label`) — the
  labels the macro clicks to choose the next room. Add any `room-*` curse label
  (`room-shopping`, `room-health`, `room-regen`, `room-shielding`, `room-money`,
  `room-explosion`, `room-flight`, `room-wind`) if you want curse doors in the
  rotation. After a click that label is left alone for five seconds, so one click
  means one choice and a slow loading screen is not double-clicked.
- **Shrines** (default vitality → armor → burst → eruption …) — shrine icons on the
  shrine screen. When none of them is on screen the macro falls through to the
  normal Next / Continue button instead of clicking blindly.
- **Shop** (default the three shipped shop items) — item icons in the dungeon shop.

**Buys per shop** is a budget for one shop visit, not per loop; it resets when the
shop closes. **Chests** (`End` saves reward chests for the end, `Now` opens each
reward panel as it appears) and **Stop at hearts** control the rest. The heart
count is read with OCR from the top of the HUD; at or below the limit the macro
pauses clicking and notifies you, then resumes once the count is higher or the
run ends. If the HUD does not show a readable heart count the log says so once and
the option has no effect.

### Private server and webhook

Paste a Roblox private-server share link to have the macro rejoin it after a
disconnect. Paste a Discord webhook URL to get a session summary when a run
finishes.

## How a run works

```
ensure in game (reconnect if the disconnect screen is up)
→ replay start clicks
→ place units (hotkey, click, upgrades)
→ mode phase:
    Infinite: wait for "Wave 6" via Vision OCR → Vote → your vote clicks
    Summer:   play the run until Victory / Defeat
    Dungeon:  pick room labels / shrines / shop by priority, advance on Next,
              open chests (now or at the end), pause on low hearts, until
              Victory / Death, then click through every reward panel
→ click Reward Continue / Next Level / Next Room / Replay
→ next run
```

Between every step — and inside every long wait, and immediately before each
click and key press — the captcha guard checks the screen (at most every 1.25 s).
If it finds a verification prompt it pauses input and alerts you, keeps re-alerting
every 90 s, and only resumes after two consecutive clear screens, so a single bad
OCR frame cannot send clicks into an open challenge.

Positions are stored as fractions of the Roblox window, so the window can move
or change size between runs. Keep it visible and unobstructed: clicks are real
screen clicks.

## Troubleshooting

**Clicks do nothing.** Accessibility permission is missing, or another window is
in front. The log prints every click with its screen coordinates. Use **Help →
macOS permissions… → Request access** so the app shows up in the list.

**The start key does nothing.** It is `]` by default and can be changed under
**Connection → Start hotkey**. Outside the app it needs Accessibility; the log
says `Global hotkeys need Accessibility` when it is missing, and the buttons
still work. Global keys are read from AppKit's event monitor, so any single
character (`]`, `w`, `1`) or function key (`F5`…`F12`) works.

**It quits the moment it opens, with a SIGTRAP / `dispatch_assert_queue_fail`
crashed thread.** That was pynput's keyboard listener asking Text Services
Manager for a key's character on a background thread, which macOS 26 aborts. The
input layer is now `capymacro/keys.py` (Quartz keycodes) and the hotkeys are an
AppKit event monitor on the main thread, and pynput is no longer a dependency, so
the crash cannot happen. Delete `.venv` if macOS keeps reporting the old build:
`rm -rf .venv && ./run.sh`.

**Python quits unexpectedly / the window vanishes.** Every launch now writes
`data/crash.log` (a Python-level traceback, including native crashes). Send that
file, or the newest `~/Library/Logs/DiagnosticReports/Python-*.ips`, together with
the last log lines before it exited.

**Double-clicking CapyMacro.app does nothing / “CapyMacro stopped”.** The bundle
writes everything the launcher does to `data/launch.log` — open that file; it ends
with the actual reason. Exit code 126 means `run.sh` was not executable after
unzipping; the current launcher runs it through `bash`, so recreate the app
(**Permissions → Create CapyMacro.app**) to pick that up. The launcher has the
project path baked in, so moving the project also needs a fresh app. If macOS
refuses to open an unsigned bundle, right-click it → **Open** once, or run
`xattr -dr com.apple.quarantine CapyMacro.app` in Terminal.

**Permissions are granted but the macro still cannot click.** macOS grants to a
*specific* app identity: a bundle launched from Finder is **not** Terminal, so
Terminal's Accessibility/Screen Recording do not carry over. Either grant
everything to `CapyMacro.app` as well, or launch with `launch.command` so the
process really runs inside Terminal. Fastest check from Terminal:

```bash
cd ~/Downloads/capymacro-mac
chmod +x run.sh launch.command grant_permissions.command
./run.sh
```

That prints any error in the window instead of hiding it in a log.

**Play is never pressed.** Press **Screen check** in the header: it logs the
window size, whether the screenshot worked and the text Apple Vision reads. If it
reports `screenshot FAILED` or `OCR is unavailable`, Screen Recording is missing.
When Play is not found the log also prints `Auto play: OCR saw: …` — the Play
button must be visible as a short “Play” label on the Roblox experience page (it
does not exist while you are already in the game).

**"Roblox not found".** Window lookup now includes other Spaces and fullscreen
desktops and picks the largest Roblox window, so this should only happen when
Roblox is quit or minimised. Press **Screen check**: if it still fails it logs
the window titles it can see (`Screen check: windows it can see: …`), which
tells us whether the name filter or Screen Recording is the problem.

**Wave detection never triggers.** Vision OCR needs Screen Recording permission
and a visible wave counter. Without OCR the engine falls back to a fixed wait
(`fallback_vote_seconds` in `data/farm.json`, 240s by default).

**Dungeon run stalls on a screen.** The names in the priority lists are template
files; a typo simply never matches. The run stops with a timeout message rather
than clicking at random — check the names against `templates/AA`, and add the
screen's Next / Continue button if it has none of the configured labels.

**"Stop at hearts" does nothing.** The heart count is read with OCR. If your
HUD shows hearts as icons without a readable number, the log says so once and the
option stays inactive. Set it to 0 to silence it.

**Captcha guard logs that it is off.** It needs Apple Vision OCR (macOS with
Screen Recording permission); on any other machine it disables itself instead of
pretending to watch the screen.

**Upgrade button not found.** Upgrades are clicked through the
`upgrade-max-button` template. If your UI shows a different button, set upgrades
to 0 and add placements after manual upgrades, or recapture that template.

**Template misses.** The shipped images come from the Windows release at a
specific UI scale. Keep Roblox at its default window size and 100% UI scale; if a
detection still misses, the log shows what was being looked for.

**Macro behaves oddly after a game update.** Screen layouts change with updates;
update the affected template PNGs in `templates/AA/`.

## Layout

| Path | Contents |
| --- | --- |
| `capymacro/aa/farm.py` | the run engine (Infinite, Summer, Dungeon) |
| `capymacro/aa/placement.py` | circle and centre-out placements |
| `capymacro/aa/mapscan.py` | reads the stage name and matches it to a map config |
| `capymacro/aa/onscreen.py` | Play / Reconnect buttons and disconnect notices (OCR) |
| `capymacro/aa/captcha.py` | human-verification detection and alert |
| `capymacro/aa/assets.py` | template index, screenshot/locate/click layer |
| `capymacro/aa/configs.py` | reader for the shipped map configs |
| `capymacro/aa/session.py` | stats and Discord webhook |
| `capymacro/vision.py` | Apple Vision OCR, wave numbers and the heart count |
| `capymacro/ui/` | the app window, unit cards, point picker, live view and preview |
| `capymacro/keys.py` | Quartz keycodes, key presses and clicks (no pynput) |
| `capymacro/hotkeys.py` | start key and Esc through AppKit's global event monitor |
| `capymacro/permissions.py` | asks macOS for Screen Recording, Accessibility and Input Monitoring |
| `grant_permissions.command` | opens the three privacy panes in System Settings |
| `templates/AA/` | 106 detection templates from the original release |
| `configs/` | 58 Infinite/Summer map configs |
| `data/farm.json` | your setup (created on first save) |

## Notes

- Mac only by design: window lookup, display scaling, OCR and synthetic input use
  Quartz/AppKit/Vision.
- This automates your own account on your own Mac. Roblox allows third-party
  macros only within its terms; use it at your own risk.
- Not affiliated with Capybara Land, Roblox Corporation or the Anime Adventures
  developers.
