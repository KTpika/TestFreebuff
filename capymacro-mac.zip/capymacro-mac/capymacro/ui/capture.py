"""Click-anywhere overlay used to pick screen points."""

from __future__ import annotations

from PySide6.QtCore import QPoint, QRect, Qt, Signal
from PySide6.QtGui import QColor, QGuiApplication, QPainter
from PySide6.QtWidgets import QWidget


class PointPicker(QWidget):
    """Dim the screen and emit the global point the user clicks."""

    picked = Signal(object)  # QPoint in global points, or None when cancelled

    def __init__(self, parent=None, message: str = "Click the spot to record  ·  Esc or right-click to cancel"):
        super().__init__(parent, Qt.Window | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAttribute(Qt.WA_DeleteOnClose, True)
        self.setCursor(Qt.CrossCursor)
        self.setFocusPolicy(Qt.StrongFocus)

        self._message = message
        self._bounds = self._virtual_geometry()
        self.setGeometry(self._bounds)

    @staticmethod
    def _virtual_geometry() -> QRect:
        geometry = QRect()
        for screen in QGuiApplication.screens():
            geometry = geometry.united(screen.geometry())
        return geometry

    def showEvent(self, event) -> None:
        super().showEvent(event)
        self.raise_()
        self.activateWindow()
        self.setFocus()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(10, 12, 16, 130))
        painter.setPen(QColor(255, 255, 255))
        painter.drawText(self.rect(), int(Qt.AlignCenter), self._message)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.RightButton:
            self._cancel()
            return
        if event.button() == Qt.LeftButton:
            local = event.position().toPoint()
            global_point = QPoint(local)
            global_point += self._bounds.topLeft()
            self.picked.emit(global_point)
            self.close()

    def keyPressEvent(self, event) -> None:
        if event.key() == Qt.Key_Escape:
            self._cancel()
            return
        super().keyPressEvent(event)

    def _cancel(self) -> None:
        self.picked.emit(None)
        self.close()
