"""Reading the map/mode configs that ship with the macro."""

from __future__ import annotations

import configparser
from dataclasses import dataclass
from pathlib import Path

from .. import CONFIGS


@dataclass(frozen=True)
class MapConfig:
    mode: str
    map_name: str
    act: int
    difficulty: str
    runs: int
    team: int
    path: Path
    display_name: str = ""

    @property
    def label(self) -> str:
        return f"{self.mode} · {self.map_name}"


def _read_ini(path: Path) -> configparser.ConfigParser:
    parser = configparser.ConfigParser()
    text = path.read_text(encoding="utf-16", errors="replace")
    parser.read_string(text)
    return parser


def load_maps(mode: str | None = None) -> list[MapConfig]:
    """Every map config, optionally limited to one mode ("Infinite"/"Summer")."""
    found: list[MapConfig] = []
    if not CONFIGS.exists():
        return found

    for path in sorted(CONFIGS.rglob("*.txt")):
        try:
            parser = _read_ini(path)
            section = parser["Settings"]
        except Exception:
            continue

        map_mode = section.get("Mode", path.parent.name)
        if mode and map_mode.lower() != mode.lower():
            continue

        try:
            act = int(section.get("Act", "1"))
        except ValueError:
            act = 1
        try:
            runs = int(section.get("Runs", "1"))
        except ValueError:
            runs = 1
        try:
            team = int(section.get("Team", "0"))
        except ValueError:
            team = 0

        found.append(
            MapConfig(
                mode=map_mode,
                map_name=section.get("Map", path.stem),
                act=act,
                difficulty=section.get("Difficulty", "Normal"),
                runs=runs,
                team=team,
                path=path,
                display_name=section.get("DisplayName", ""),
            )
        )

    return found
