"""Per-unit card: enabled, ordering, copy count and upgrade limit."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QSpinBox,
    QVBoxLayout,
)

from ..aa.farm import UnitSettings


class UnitCard(QGroupBox):
    """One card from the unit grid (Unit 1 … Unit 6)."""

    def __init__(self, settings: UnitSettings, parent=None):
        super().__init__(parent)
        self.slot = settings.slot
        self.setTitle(f"Unit {self.slot}")

        self.enabled = QCheckBox("Enabled")
        self.enabled.setToolTip("Off: this unit is never placed or upgraded.")
        header = QHBoxLayout()
        header.addStretch(1)
        header.addWidget(self.enabled)

        self.place_priority = QSpinBox()
        self.place_priority.setRange(1, 6)
        self.place_priority.setToolTip("Lower number is placed first.")

        self.upgrade_priority = QSpinBox()
        self.upgrade_priority.setRange(1, 6)
        self.upgrade_priority.setToolTip("Lower number is upgraded first.")

        self.placements = QSpinBox()
        self.placements.setRange(0, 30)
        self.placements.setToolTip(
            "How many copies of this unit to place. 0 uses every recorded position."
        )

        self.upgrade_limit = QSpinBox()
        self.upgrade_limit.setRange(0, 30)
        self.upgrade_limit.setToolTip(
            "Maximum upgrade clicks for this unit. Only used with Enable upgrade limit."
        )

        self.limit_on = QCheckBox("Enable upgrade limit")
        self.limit_on.setToolTip("Cap this unit's upgrades at Upgrade limit.")

        self.auto_ability = QCheckBox("Auto ability")
        self.auto_ability.setToolTip(
            "Press the ability key after placing this unit (set it under Connection → Ability key)."
        )

        self.hill = QCheckBox("Hill")
        self.hill.setToolTip(
            "Saved with the unit. Separate hill spots are not recorded yet, so it changes nothing."
        )

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(4)
        grid.addWidget(QLabel("Placement priority"), 0, 0)
        grid.addWidget(self.place_priority, 0, 1)
        grid.addWidget(QLabel("Upgrade priority"), 0, 2)
        grid.addWidget(self.upgrade_priority, 0, 3)
        grid.addWidget(QLabel("Placements"), 1, 0)
        grid.addWidget(self.placements, 1, 1)
        grid.addWidget(QLabel("Upgrade limit"), 1, 2)
        grid.addWidget(self.upgrade_limit, 1, 3)

        toggles = QHBoxLayout()
        toggles.addWidget(self.auto_ability)
        toggles.addWidget(self.hill)
        toggles.addStretch(1)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 6, 10, 8)
        layout.setSpacing(4)
        layout.addLayout(header)
        layout.addLayout(grid)
        layout.addWidget(self.limit_on)
        layout.addLayout(toggles)

        self.limit_on.toggled.connect(self._sync_limit)
        self.load(settings)

    def _sync_limit(self) -> None:
        self.upgrade_limit.setEnabled(self.limit_on.isChecked())

    def load(self, settings: UnitSettings) -> None:
        self.enabled.setChecked(settings.enabled)
        self.place_priority.setValue(settings.place_priority)
        self.upgrade_priority.setValue(settings.upgrade_priority)
        self.placements.setValue(settings.placements)
        self.upgrade_limit.setValue(settings.upgrade_limit)
        self.limit_on.setChecked(settings.enable_upgrade_limit)
        self.auto_ability.setChecked(settings.auto_ability)
        self.hill.setChecked(settings.hill)
        self._sync_limit()

    def settings(self) -> UnitSettings:
        return UnitSettings(
            slot=self.slot,
            enabled=self.enabled.isChecked(),
            place_priority=self.place_priority.value(),
            upgrade_priority=self.upgrade_priority.value(),
            placements=self.placements.value(),
            upgrade_limit=self.upgrade_limit.value(),
            enable_upgrade_limit=self.limit_on.isChecked(),
            auto_ability=self.auto_ability.isChecked(),
            hill=self.hill.isChecked(),
        )
